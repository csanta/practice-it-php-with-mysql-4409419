<?php
//============================================================+
// File name   : example_018.php
// Begin       : 2008-03-06
// Last Update : 2013-05-14
//
// Description : Example 018 for TCPDF class
//               RTL document with Persian language
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: RTL document with Persian language
 * @author Nicola Asuni
 * @since 2008-03-06
 */

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');

class HTML2PDFApi {
	public function CreateNewAuthoForm($auth_form_filename, $reservation, $timestamp) {

		/* create new PDF document */
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		// set document information
		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor('Tortuga Properties');
		$pdf->SetTitle('Authorization Form - Fairway Courts - Palmas del Mar');
		$pdf->SetSubject('Guests Authorization Form');
		$pdf->SetKeywords('Authorization Form');

		// set default header data
		$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.'', PDF_HEADER_STRING);

		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

		// set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

		// set image scale factor
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

		// set some language dependent data:
		$lg = Array();
		$lg['a_meta_charset'] = 'UTF-8';
		$lg['a_meta_dir'] = 'rtl';
		$lg['a_meta_language'] = 'fa';
		$lg['w_page'] = 'page';

		// set some language-dependent strings (optional)
		$pdf->setLanguageArray($lg);

		// ---------------------------------------------------------

		// set font
		$pdf->SetFont('helvetica', '', 12);

		// add a page
		$pdf->AddPage();


		// set LTR direction for english translation
		$pdf->setRTL(false);

		$pdf->SetFontSize(12);

		// print newline
		$pdf->Ln();

		// Authorization Form Content
		$formContent = '<h2>&nbsp;</h2>
		<h2><strong>VISITOR</strong><br />Authorization Form</h2>
		<p>Date: '.$timestamp.'</p>
		<p>&nbsp;</p>
		<h2>Owner Information</h2>
		<table style="width: 312.5px;">
		<tbody>
		<tr>
		<td style="width: 173.5px;"><strong>Villa</strong>:</td>
		<td style="width: 312.5px;">FWC #' .$reservation['villa_id']. '&nbsp;</td>
		</tr>
		<tr>
		<td style="width: 173.5px;"><strong>Owner</strong>:</td>
		<td style="width: 312.5px;">Carlos Santa/Serge Blazhiesvky</td>
		</tr>
		<tr>
		<td style="width: 173.5px;"><strong>Phone</strong>:</td>
		<td style="width: 312.5px;">469-569-7081</td>
		</tr>
		</tbody>
		</table>
		<h2>&nbsp;</h2>
		<h2>Visitor Personal Information</h2>
		<table style="width: 305px;">
		<tbody>
		<tr>
		<td style="width: 165px;"><strong>Name</strong>:</td>
		<td style="width: 128px;">' .$reservation['first_name']. ' ' .$reservation['last_name'].'</td>
		</tr>
		<tr>
		<td style="width: 165px;"><strong>Phone</strong>:</td>
		<td style="width: 128px;">' .$reservation['phone']. '</td>
		</tr>
		<tr>
		<td style="width: 165px;"><strong>Total # of Guests:</strong></td>
		<td style="width: 128px;">' .$reservation['total_guests']. '</td>
		</tr>
		<tr>
		<td style="width: 165px;"><strong>Arrival Date:</strong></td>
		<td style="width: 128px;">' .$reservation['check_in']. '</td>
		</tr>
		<tr>
		<td style="width: 165px;"><strong>Departure Date:</strong></td>
		<td style="width: 128px;">' .$reservation['check_out']. '</td>
		</tr>
		</tbody>
		</table>
		<h2>&nbsp;</h2>
		<h2>Additional Information</h2>
		<table style="width: 305px;">
		<tbody>
		<tr>
		<td style="width: 265px;"><strong>List of Names</strong></td>
		<td style="width: 265px;">&nbsp;</td>
		</tr>
		<tr>
		<td style="width: 265px;">' .$reservation['guest_list']. '</td>
		<td style="width: 265px;">&nbsp;</td>
		</tr>
		<tr>
		<td style="width: 265px;">&nbsp;</td>
		<td style="width: 265px;">&nbsp;</td>
		</tr>
		<tr>
		<td style="width: 265px;">&nbsp;</td>
		<td style="width: 265px;">&nbsp;</td>
		</tr>
		<tr>
		<td style="width: 265px;">&nbsp;</td>
		<td style="width: 265px;">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		<p>&nbsp;</p>
		<p><strong>Notes:</strong><br /> Internal Reservation ID: #' .$reservation['id']. '</p>';

		$pdf->WriteHTML($formContent, true, 0, true, 0);

		// Restore RTL direction
		$pdf->setRTL(true);

		// ---------------------------------------------------------

		//Close and output PDF document
		return $pdf->Output($_SERVER['DOCUMENT_ROOT'] . PROJECT_ROOT . '/public/authorization_forms/' . $reservation['villa_id'] . '/' . $auth_form_filename, 'F');
	}

}

//============================================================+
// END OF FILE
//============================================================+
