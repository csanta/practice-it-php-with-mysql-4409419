<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('initialize.php');

/* Google App Client Id */
define('CLIENT_ID', '928169699334-eqgg0pu2a8ikljnl17rs5jplunqssesr.apps.googleusercontent.com');

define('BEACH_HOUSES_GROUP_CALENDAR', 'mapu7sns3oisvsj8lp6gm543hs@group.calendar.google.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'XVAa9P6IS_lkLuPGemLhV1AM');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://www.rusticasoftware.com:80' . PROJECT_ROOT . '/home.php');
// http://71.237.254.210/db/t2/public/staff/index.php 
//http://71.237.254.210:80/29-1/google-login.php
// http://localhost:80/29-1/google-login.php
//http://c-71-237-254-210.hsd1.or.comcast.net/29-1/google-login.php

?>
