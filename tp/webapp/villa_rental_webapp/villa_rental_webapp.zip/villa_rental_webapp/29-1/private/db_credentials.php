<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

define("DB_SERVER", "localhost");
define("DB_USER", "phpmyadmin");
define("DB_PASS", "test0000");
define("DB_NAME", "reservations");

?>
