<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

  function run_query($sql) {
    global $db;

    $result = mysqli_query($db,$sql);
    confirm_result_set($result);
    return $result;
  }

  // Subjects
  function find_all_subjects($options=[]) {
    global $db;

    //$visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM reservation ";
    /*if($visible) {
      $sql .= "WHERE visible = true ";
    }*/
    $sql .= "ORDER BY reservation_id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_subject_by_id($id, $options=[]) {
    global $db;

    $sql = "SELECT * FROM reservation ";
    $sql .= "WHERE reservation_id='" . db_escape($db, $id) . "' ";
     //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $subject = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $subject; // returns an assoc. array
  }

  /* Returns a Google Calendar event ID based on the reservation ID */
  function find_gapi_calendar_event_by_id($id) {
    global $db;

    $sql = "SELECT * FROM reservation ";
    $sql .= "WHERE reservation_id='" . db_escape($db, $id) . "' ";
    //echo "sql ".$sql." \n";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $reservation = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    //echo "gapi_event: ".$reservation['gapi_calendar_id']."/n";
    return $reservation['gapi_calendar_id'];
  }

  function find_total_pages($no_of_records_per_page) {
    global $db;
    $total_pages_sql = "SELECT COUNT(*) FROM reservation";
    $result = mysqli_query($db, $total_pages_sql);
    confirm_result_set($result);
    $total_rows = mysqli_fetch_array($result)[0];
    $total_pages = ceil($total_rows / $no_of_records_per_page);    
    //echo " inside " . $total_pages . " ";
    return $total_pages;
  }

  function find_total_pages_in_invoices($no_of_records_per_page) {
    global $db;
    $total_pages_sql = "SELECT COUNT(*) FROM invoices";
    $result = mysqli_query($db, $total_pages_sql);
    confirm_result_set($result);
    $total_rows = mysqli_fetch_array($result)[0];
    $total_pages = ceil($total_rows / $no_of_records_per_page);
    //echo " inside " . $total_pages . " ";
    return $total_pages;
  }

  function find_total_reservation_records($table_name) {
    global $db;
    $total_pages_sql = "SELECT COUNT(*) FROM ".$table_name;
    $result = mysqli_query($db, $total_pages_sql);
    confirm_result_set($result);
    $total_rows = mysqli_fetch_array($result)[0];
    return $total_rows;
  }

  /* find the "order number id" of the last invoice,
   * this is required to determine what the new order #
   * should be for new invoices
   */
  function find_new_order_id() {
    global $db;

    $sql = "SELECT * FROM invoices ";
    $sql .= "ORDER BY invoice_id DESC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $invoice = mysqli_fetch_assoc($result);
    mysqli_free_result($result);

    return $invoice['order_no'];
  }

  /* find the "order number id" of the last invoice,
   * this is required to determine what the new order #
   * should be for new invoices
   */
  function find_order_no_by_invoice_id($invoice_id) {
    global $db;

    $sql = "SELECT * FROM invoices ";
    $sql .= "WHERE invoice_id='" . db_escape($db, $invoice_id) . "' ";
    $sql .= "LIMIT 1";
    //echo "sql: ".$sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $invoice = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    //echo "invoice['order_no']: ".$invoice['order_no'];
    return $invoice['order_no'];
  }

  /* select * from employee limit 2,4 */
  /* Returning a range of rows from a table called employee (starting at record 2, return the next 4 rows): */
  function find_all_orders($order_no, $no_of_orders_per_invoice) {
    global $db;

    $sql = "SELECT * FROM invoices ";
    $sql .= "WHERE order_no='" . db_escape($db, $order_no) . "' ";
    $sql .= "LIMIT $no_of_orders_per_invoice";
    //echo "sql: ".$sql;
    $res_data = mysqli_query($db, $sql);
    $i = 0;
    while($row = mysqli_fetch_assoc($res_data)) {
      $invoice[$i]['invoice_id'] = $row['invoice_id'];
      $invoice[$i]['order_no'] = $row['order_no'];
      $invoice[$i]['order_receiver_name'] = $row['order_receiver_name'];
      $invoice[$i]['order_receiver_address'] = $row['order_receiver_address'];
      $invoice[$i]['order_receiver_email'] = $row['order_receiver_email'];
      $invoice[$i]['order_receiver_phone'] = $row['order_receiver_phone'];
      $invoice[$i]['order_date'] = $row['order_date'];
      $invoice[$i]['order_no'] = $row['order_no'];
      $invoice[$i]['order_due_date'] = $row['order_due_date'];
      $invoice[$i]['order_item_name'] = $row['order_item_name'];
      $invoice[$i]['order_item_quantity'] = $row['order_item_quantity'];
      $invoice[$i]['order_item_price'] = $row['order_item_price'];
      $invoice[$i]['order_item_amount'] = $row['order_item_amount'];
      $invoice[$i]['order_tax_rate'] = $row['order_tax_rate'];
      $invoice[$i]['order_tax_rate_amount'] = $row['order_tax_rate_amount'];
      $invoice[$i]['order_item_final_amount'] = $row['order_item_final_amount'];
      $invoice[$i]['order_total_pretax'] = $row['order_total_pretax'];
      $invoice[$i]['order_total_tax_amount'] = $row['order_total_tax_amount'];
      $invoice[$i]['order_total'] = $row['order_total'];
      $i++;
    }
    //echo " result: ".mysqli_error($db);/*LIMIT $invoice_id, $no_of_orders_per_invoice*/
    return $invoice; // returns an assoc. array
  }

  function dropMenu() {

    global $db;
    $sql = "SELECT * FROM reservation ";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $options = "";
    while($row=mysqli_fetch_array($result)) {
      $options = $options."<option>$row[reservation_id]. $row[first_name] $row[last_name]</option>";
    }
    //mysqli_free_result($result);
    return $options;

  }

  function find_reservations_by_pages($no_of_records_per_page, $page_offset, $queryCondition) {
    global $db;

    $sql = "SELECT * FROM reservation $queryCondition LIMIT $page_offset, $no_of_records_per_page";
    $res_data = mysqli_query($db, $sql);
    return $res_data; // returns an assoc. array
  }

  function find_invoices_by_pages($no_of_records_per_page, $page_offset, $queryCondition) {
    global $db;

    $sql = "SELECT * FROM invoices $queryCondition LIMIT $page_offset, $no_of_records_per_page";
    $res_data = mysqli_query($db, $sql);
    return $res_data; // returns an assoc. array
  }

  function validate_subject($subject) {
    $errors = [];

    // menu_name
    if(is_blank($subject['menu_name'])) {
      $errors[] = "Name cannot be blank.";
    } elseif(!has_length($subject['menu_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters.";
    }

    // position
    // Make sure we are working with an integer
    $postion_int = (int) $subject['position'];
    if($postion_int <= 0) {
      $errors[] = "Position must be greater than zero.";
    }
    if($postion_int > 999) {
      $errors[] = "Position must be less than 999.";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $subject['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false.";
    }

    return $errors;
  }

/*Convert a mm/dd/yyyy into yyyy-mm-dd for mysql*/
function parsedate($date){
    $d = strptime($date , '%m/%d/%Y');

    if($d)
        $date = ($d['tm_year']+1900).'-'.($d['tm_mon']+1).'-'.$d['tm_mday'];
    else
        $date = '1800-01-01';
    
    return $date;
}

function insert_invoice($invoice_arr) {
    global $db;

    //$invoice_due_date,

    $i = 0;
    //$error = mysql_error($db);
    mysqli_report(MYSQLI_REPORT_ERROR );
    foreach ($invoice_arr as $key => $value) {
      $sql = "INSERT into invoices ";
      $sql .= "(order_no,order_receiver_name,order_receiver_address,order_receiver_email,order_receiver_phone,order_date,order_due_date,order_item_name,order_item_quantity,order_item_price,order_item_amount,order_tax_rate,order_tax_rate_amount,order_item_final_amount,order_total_pretax,order_total_tax_amount,order_total,order_row_id_count) ";
      $sql .= "VALUES (";
      $sql .= "'" . db_escape($db, $value[$i][0]) . "',";//order_no
      $sql .= "'" . db_escape($db, $value[$i][1]) . "',";//order_receiver_name
      $sql .= "'" . db_escape($db, $value[$i][2]) . "',";//order_receiver_address
      $sql .= "'" . db_escape($db, $value[$i][3]) . "',";//order_receiver_email
      $sql .= "'" . db_escape($db, $value[$i][4]) . "',";//order_receiver_phone
      $sql .= "'" . db_escape($db, $value[$i][5]) . "',";//order_date
      $sql .= "'" . db_escape($db, $value[$i][6]) . "',";//order_due_date
      $sql .= "'" . db_escape($db, $value[$i][7]) . "',";//order_item_name
      $sql .= "'" . db_escape($db, $value[$i][8]) . "',";//order_item_quantity
      $sql .= "'" . db_escape($db, $value[$i][9]) . "',";//order_item_price
      $sql .= "'" . db_escape($db, $value[$i][10]) . "',";//order_item_amount
      $sql .= "'" . db_escape($db, $value[$i][11]) . "',";//order_tax_rate
      $sql .= "'" . db_escape($db, $value[$i][12]) . "',";//order_tax_rate_amount
      $sql .= "'" . db_escape($db, $value[$i][13]) . "',";//order_item_final_amount
      $sql .= "'" . db_escape($db, $value[$i][14]) . "',";//order_total_pretax
      $sql .= "'" . db_escape($db, $value[$i][15]) . "',";//order_total_tax_amount
      $sql .= "'" . db_escape($db, $value[$i][16]) . "',";//order_total
      $sql .= "'" . db_escape($db, $value[$i][17]) . "'";//order_row_id_count
      $sql .= ")";
      $result = mysqli_query($db, $sql);
      //echo "sql : ".$sql;
      //echo " result: ".mysqli_error($db);
      //$error = mysql_error($db);
      //echo "mysql_error: "$error;

      // For INSERT statements, $result is true/false
      /*if(!$result) {
        // INSERT failed
        //echo mysqli_error($db);
        db_disconnect($db);
        exit;
      }*/

      $i++;
    }
}

  function update_invoice($invoice) {
    global $db;

    //FIXME: Implement input validation
    /*$errors = validate_subject($subject);
    if(!empty($errors)) {
      return $errors;
    }*/

    $sql = "UPDATE invoices SET ";
    $sql .= "order_receiver_name='" . db_escape($db, $invoice['order_receiver_name']) . "',";
    $sql .= "order_receiver_phone='" . db_escape($db, $invoice['order_receiver_phone']) . "',";
    $sql .= "order_receiver_address='" . db_escape($db, $invoice['order_receiver_address']) . "',";
    $sql .= "order_receiver_email='" . db_escape($db, $invoice['order_receiver_email']) . "' ";
    $sql .= "WHERE invoice_id='" . db_escape($db, $invoice['invoice_id']) . "' ";
    $sql .= "LIMIT 1";

    //echo $sql;

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function insert_reservation($reserv) {
    global $db;

      //TODO
    /*$errors = validate_subject($reservation);
    if(!empty($errors)) {
      return $errors;
    }*/
    $sql = "INSERT into reservation ";
    $sql .= "(first_name,last_name,email,street,city,state,zip,phone,platform,check_in,check_out,total_guests,villa_id,villa_name,packet_timestamp,gapi_calendar_id,guest_list) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $reserv['first_name']) . "',";
    $sql .= "'" . db_escape($db, $reserv['last_name']) . "',";
    $sql .= "'" . db_escape($db, $reserv['email']) . "',";
    $sql .= "'" . db_escape($db, $reserv['street']) . "',";
    $sql .= "'" . db_escape($db, $reserv['city']) . "',";
    $sql .= "'" . db_escape($db, $reserv['state']) . "',";
    $sql .= "'" . db_escape($db, $reserv['zip']) . "',";
    $sql .= "'" . db_escape($db, $reserv['phone']) . "',";
    $sql .= "'" . db_escape($db, $reserv['platform']) . "',";
    $sql .= "'" . db_escape($db, $reserv['check_in']) . "',";
    $sql .= "'" . db_escape($db, $reserv['check_out']) . "',";
    $sql .= "'" . db_escape($db, $reserv['total_guests']) . "',";
    $sql .= "'" . db_escape($db, $reserv['villa_id']) . "',";
    $sql .= "'" . db_escape($db, $reserv['villa_name']) . "',";
    $sql .= "'" . db_escape($db, $reserv['packet_timestamp']) . "',";
    $sql .= "'" . db_escape($db, $reserv['gapi_calendar_id']) . "',";
    $sql .= "'" . db_escape($db, $reserv['guest_list']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);    

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

    function delete_reservation_with_gapi_id($gapi_id) {
    global $db;

    $sql = "DELETE FROM reservation ";
    $sql .= "WHERE gapi_calendar_id='" . db_escape($db, $gapi_id) . "' ";
    $sql .= "LIMIT 1";
    //echo $sql;
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

    function delete_reservation_with_id($id) {
    global $db;

    $sql = "DELETE FROM reservation ";
    $sql .= "WHERE reservation_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    //echo $sql;
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function insert_subject($subject) {
    global $db;

    $errors = validate_subject($subject);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "INSERT INTO reservation ";
    $sql .= "(menu_name, position, visible) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $subject['menu_name']) . "',";
    $sql .= "'" . db_escape($db, $subject['position']) . "',";
    $sql .= "'" . db_escape($db, $subject['visible']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_reservation($reserv) {
    global $db;

    //FIXME: Implement input validation
    /*$errors = validate_subject($subject);
    if(!empty($errors)) {
      return $errors;
    }*/

    $sql = "UPDATE reservation SET ";
    $sql .= "first_name='" . db_escape($db, $reserv['first_name']) . "',";
    $sql .= "last_name='" . db_escape($db, $reserv['last_name']) . "',";
    $sql .= "email='" . db_escape($db, $reserv['email']) . "',";
    $sql .= "street='" . db_escape($db, $reserv['street']) . "',";
    $sql .= "city='" . db_escape($db, $reserv['city']) . "',";
    $sql .= "state='" . db_escape($db, $reserv['state']) . "',";
    $sql .= "zip='" . db_escape($db, $reserv['zip']) . "',";
    $sql .= "phone='" . db_escape($db, $reserv['phone']) . "',";
    $sql .= "platform='" . db_escape($db, $reserv['platform']) . "',";
    $sql .= "check_in='" . db_escape($db, $reserv['check_in']) . "',";
    $sql .= "check_out='" . db_escape($db, $reserv['check_out']) . "',";
    $sql .= "total_guests='" . db_escape($db, $reserv['total_guests']) . "',";
    $sql .= "villa_id='" . db_escape($db, $reserv['villa_id']) . "',";
    $sql .= "villa_name='" . db_escape($db, $reserv['villa_name']) . "',";
    $sql .= "guest_list='" . db_escape($db, $reserv['guest_list']) . "',";
    $sql .= "packet_timestamp='" . db_escape($db, $reserv['packet_timestamp']) . "' ";
    $sql .= "WHERE reservation_id='" . db_escape($db, $reserv['id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);

    //echo $sql;

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_subject($id) {
    global $db;

    $sql = "DELETE FROM reservation ";
    $sql .= "WHERE reservation_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    //echo $sql;
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  // Pages

  function find_all_pages() {
    global $db;

    $sql = "SELECT * FROM pages ";
    $sql .= "ORDER BY subject_id ASC, position ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_page_by_id($id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM pages ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    if($visible) {
      $sql .= "AND visible = true";
    }
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $page = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $page; // returns an assoc. array
  }

  function validate_page($page) {
    $errors = [];

    // subject_id
    if(is_blank($page['subject_id'])) {
      $errors[] = "Subject cannot be blank.";
    }

    // menu_name
    if(is_blank($page['menu_name'])) {
      $errors[] = "Name cannot be blank.";
    } elseif(!has_length($page['menu_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters.";
    }
    $current_id = $page['id'] ?? '0';
    if(!has_unique_page_menu_name($page['menu_name'], $current_id)) {
      $errors[] = "Menu name must be unique.";
    }


    // position
    // Make sure we are working with an integer
    $postion_int = (int) $page['position'];
    if($postion_int <= 0) {
      $errors[] = "Position must be greater than zero.";
    }
    if($postion_int > 999) {
      $errors[] = "Position must be less than 999.";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $page['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false.";
    }

    // content
    if(is_blank($page['content'])) {
      $errors[] = "Content cannot be blank.";
    }

    return $errors;
  }

  function insert_page($page) {
    global $db;

    $errors = validate_page($page);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "INSERT INTO pages ";
    $sql .= "(subject_id, menu_name, position, visible, content) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $page['subject_id']) . "',";
    $sql .= "'" . db_escape($db, $page['menu_name']) . "',";
    $sql .= "'" . db_escape($db, $page['position']) . "',";
    $sql .= "'" . db_escape($db, $page['visible']) . "',";
    $sql .= "'" . db_escape($db, $page['content']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_page($page) {
    global $db;

    $errors = validate_page($page);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE pages SET ";
    $sql .= "subject_id='" . db_escape($db, $page['subject_id']) . "', ";
    $sql .= "menu_name='" . db_escape($db, $page['menu_name']) . "', ";
    $sql .= "position='" . db_escape($db, $page['position']) . "', ";
    $sql .= "visible='" . db_escape($db, $page['visible']) . "', ";
    $sql .= "content='" . db_escape($db, $page['content']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $page['id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_page($id) {
    global $db;

    $sql = "DELETE FROM pages ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function find_pages_by_subject_id($subject_id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM pages ";
    $sql .= "WHERE subject_id='" . db_escape($db, $subject_id) . "' ";
    if($visible) {
      $sql .= "AND visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  // Admins

  // Find all admins, ordered last_name, first_name
  function find_all_admins() {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "ORDER BY last_name ASC, first_name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function find_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

    function find_admin_by_email($email) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE email='" . db_escape($db, $email) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_admin($admin) {
    if(is_blank($admin['first_name'])) {
      $errors[] = "First name cannot be blank." . $admin['first_name'];
    }
    elseif (!has_length($admin['first_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "First name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['last_name'])) {
      $errors[] = "Last name cannot be blank.";
    } elseif (!has_length($admin['last_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "Last name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif (!has_length($admin['email'], array('max' => 255))) {
      $errors[] = "Email must be less than 255 characters.";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email must be a valid format.";
    }

    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank.";
    } elseif (!has_length($admin['username'], array('min' => 8, 'max' => 255))) {
      $errors[] = "Username must be between 8 and 255 characters.";
    } elseif (!has_unique_username($admin['username'], $admin['id'] ?? 0)) {
      $errors[] = "Username not allowed. Try another.";
    }

    if(is_blank($admin['password'])) {
      $errors[] = "Password cannot be blank.";
    } elseif (!has_length($admin['password'], array('min' => 12))) {
      $errors[] = "Password must contain 12 or more characters";
    } elseif (!preg_match('/[A-Z]/', $admin['password'])) {
      $errors[] = "Password must contain at least 1 uppercase letter";
    } elseif (!preg_match('/[a-z]/', $admin['password'])) {
      $errors[] = "Password must contain at least 1 lowercase letter";
    } elseif (!preg_match('/[0-9]/', $admin['password'])) {
      $errors[] = "Password must contain at least 1 number";
    } elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
      $errors[] = "Password must contain at least 1 symbol";
    }

    if(is_blank($admin['confirm_password'])) {
      $errors[] = "Confirm password cannot be blank.";
    } elseif ($admin['password'] !== $admin['confirm_password']) {
      $errors[] = "Password and confirm password must match.";
    }

    return $errors;
  }

  // has_unique_username('johnqpublic')
  // * Validates uniqueness of admins.username
  // * For new records, provide only the username.
  // * For existing records, provide current ID as second argument
  //   has_unique_username('johnqpublic', 4)
  function has_unique_username($username, $current_id="0") {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "AND id != '" . db_escape($db, $current_id) . "'";

    $result = mysqli_query($db, $sql);
    $admin_count = mysqli_num_rows($result);
    mysqli_free_result($result);

    return $admin_count === 0;
  }

  // is_blank('abcd')
  // * validate data presence
  // * uses trim() so empty spaces don't count
  // * uses === to avoid false positives
  // * better than empty() which considers "0" to be empty
    function is_blank($value) {
    return empty($value) || trim($value) === '';
  }

  // has_length('abcd', ['min' => 3, 'max' => 5])
  // * validate string length
  // * combines functions_greater_than, _less_than, _exactly
  // * spaces count towards length
  // * use trim() if spaces should not count
  function has_length($value, $options) {
    if(isset($options['min']) && !has_length_greater_than($value, $options['min'] - 1)) {
      return false;
    } elseif(isset($options['max']) && !has_length_less_than($value, $options['max'] + 1)) {
      return false;
    } elseif(isset($options['exact']) && !has_length_exactly($value, $options['exact'])) {
      return false;
    } else {
      return true;
    }
  }

  // has_length_greater_than('abcd', 3)
  // * validate string length
  // * spaces count towards length
  // * use trim() if spaces should not count
  function has_length_greater_than($value, $min) {
    $length = strlen($value);
    return $length > $min;
  }

  // has_length_less_than('abcd', 5)
  // * validate string length
  // * spaces count towards length
  // * use trim() if spaces should not count
  function has_length_less_than($value, $max) {
    $length = strlen($value);
    return $length < $max;
  }

  // has_length_exactly('abcd', 4)
  // * validate string length
  // * spaces count towards length
  // * use trim() if spaces should not count
  function has_length_exactly($value, $exact) {
    $length = strlen($value);
    return $length == $exact;
  }

  // has_valid_email_format('nobody@nowhere.com')
  // * validate correct format for email addresses
  // * format: [chars]@[chars].[2+ letters]
  // * preg_match is helpful, uses a regular expression
  //    returns 1 for a match, 0 for no match
  //    http://php.net/manual/en/function.preg-match.php
  function has_valid_email_format($value) {
    $email_regex = '/\A[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\Z/i';
    return preg_match($email_regex, $value) === 1;
  }

  function insert_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO admins ";
    $sql .= "(first_name, last_name, email, username, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['first_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['last_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "UPDATE admins SET ";
    $sql .= "first_name='" . db_escape($db, $admin['first_name']) . "', ";
    $sql .= "last_name='" . db_escape($db, $admin['last_name']) . "', ";
    $sql .= "email='" . db_escape($db, $admin['email']) . "', ";
    $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "',";
    $sql .= "username='" . db_escape($db, $admin['username']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    echo $sql;
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_admin($admin) {
    global $db;

    $sql = "DELETE FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1;";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      //echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

?>

