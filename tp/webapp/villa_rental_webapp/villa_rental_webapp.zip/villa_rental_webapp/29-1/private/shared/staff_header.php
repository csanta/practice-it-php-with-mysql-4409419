<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

  if(!isset($page_title)) { $page_title = 'Staff Area'; }
?>

<!doctype html>

<html lang="en">

  <head>
    <title>Tortuga Properties - <?php echo h($page_title); ?></title>
    <meta charset="utf-8">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>


      <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" media="all" href="<?php echo PROJECT_ROOT?>/public/stylesheets/common.css" />
     <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
   <link rel="stylesheet" media="all" href="<?php echo PROJECT_ROOT?>/public/stylesheets/common.js" />
    <link rel="stylesheet" media="all" href="<?php echo PROJECT_ROOT?>/public/stylesheets/staff.css" />

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link href="<?php echo PROJECT_ROOT?>/public/stylesheets/tables.css" type="text/css" rel="stylesheet" />


<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.css" />

<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Amaranth" />
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Quicksand" />


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.js"></script>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css" rel="stylesheet"/>

<!-- <style type="text/css">  Some weirdness.. --> 


<link href="<?php echo PROJECT_ROOT?>/public/stylesheets/style.css" type="text/css" rel="stylesheet" />

<style>
.modal-dialog {
	width: 460px;
	transform: translate(0, -30%);
	top: 30%;
	margin: 0 auto;
}

.modal-header {
    background-color: #ff5050;
    padding:16px 16px;
    color:#FFF;
    border-bottom:2px solid #ff5050;
 }

 .modal-dialog-form {
  width: 760px;
  transform: translate(15%, 2%);
  top: 30%;
  margin: 0 auto;
}
 .modal-dialog-form2 {
  width: 472px;
  transform: translate(15%, 2%);
  top: 30%;
  margin: 0 auto;
}


</style>

<!-- Drop down menu + search -->

<link rel="stylesheet" href="<?php echo PROJECT_ROOT?>/public/stylesheets/select2.min.css" />
<style>
.select2-dropdown {top: 0px !important; left: 0px !important;}
</style>

 </head>

  <body>

</br>
    <navigation>
      <ul>
        <li>User: <?php echo $_SESSION['username'] ?? ''; ?></li>
        <li><a style="font-weight:bold" href="<?php echo PROJECT_ROOT?>/main.php">Dashboard</a></li>
        <li><a style="font-weight:bold" href="<?php echo url_for('/staff/logout.php'); ?>">Logout</a></li>
      </ul>
      <br>
    </navigation>
