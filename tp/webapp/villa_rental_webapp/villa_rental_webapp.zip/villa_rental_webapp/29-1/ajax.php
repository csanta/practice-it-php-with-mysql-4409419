<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

session_start();
header('Content-type: application/json');

require_once('./private/initialize.php');
require_once('./private/functions.php');
require_once('./private/gapi_credentials.php');
require_once('./private/google_calendar_api.php');

try {
	// Get event details
	$output = array( 'status' => null, 'event_id' => null, 
                 'first_name' => null, 'resp' => array());

	$event = $_POST['event_details'];
	$capi = new GoogleCalendarApi();
	
	switch($event['operation']) {
		case 'create':
			// Get user calendar timezone
			if(!isset($_SESSION['user_timezone']))
				$_SESSION['user_timezone'] = $capi->GetUserCalendarTimezone($_SESSION['access_token']);

			/* Create event on the master calendar */
			$beach_houses_cal_id = BEACH_HOUSES_GROUP_CALENDAR;
			$event_id = $capi->CreateCalendarEvent($beach_houses_cal_id, $event['title'], $event['description'], $event['location'], $event['colorId'], $event['all_day'], $event['event_time'], $_SESSION['user_timezone'], $_SESSION['access_token']);

			 /* Calendar Event ID */
			 $output["event_id"] = $event_id;

			  $reservation_db = [];
			  $reservation_db['first_name'] = $event['first_name'];
			  $reservation_db['last_name'] = $event['last_name'];
			  $reservation_db['email'] = $event['email'];
			  $reservation_db['street'] = $event['street'];
			  $reservation_db['city'] = $event['city'];
			  $reservation_db['state'] = $event['state'];
			  $reservation_db['zip'] = $event['zip'];
			  $reservation_db['phone'] = $event['phone'];
			  $reservation_db['platform'] = $event['platform'];
			  $reservation_db['total_guests'] = $event['total_guests'];
			  $reservation_db['villa_name'] = $event['villa_name'];
			  $reservation_db['villa_id'] = $event['villa_id'];
			  $reservation_db["check_in"] = $event['check_in'];
			  $reservation_db["check_out"] = $event['check_out'];
			  $reservation_db["packet_timestamp"] = "";
			  $reservation_db["gapi_calendar_id"] = $event_id;
			  $reservation_db["guest_list"] = $event['guest_list'];

			  $result = insert_reservation($reservation_db);

			  if($result === true) {
			    $new_id = mysqli_insert_id($db);

			    $output["status"] = $new_id;

				/* poking at the Apache DB  */
				$id = $new_id; // PHP > 7.0
				$reservation = find_subject_by_id($id);
				$output["first_name"] = $reservation['first_name'];
				$output["last_name"] = $reservation['last_name'];
				$output["email"] = $reservation['email'];
				$output["phone"] = $reservation['phone'];
				$output["street"] = $reservation['street'];
				$output["city"] = $reservation['city'];
				$output["state"] = $reservation['state'];
				$output["zip"] = $reservation['zip'];
				$output["platform"] = $reservation['platform'];
				$output["check_in"] = $reservation['check_in'];
				$output["check_out"] = $reservation['check_out'];
				$output["total_guests"] = $reservation['total_guests'];
				$output["villa_name"] = $reservation['villa_name'];
				$output["villa_id"] = $reservation['villa_id'];
				$output["gapi_calendar_id"] = $event_id;
				$output["guest_list"] = $reservation['guest_list'];
				$output["packet_timestamp"] = $reservation["packet_timestamp"];

			  } else {
			    $output["status"] = $result;
			  }

			echo json_encode($output);

			break;
	}
}
catch(Exception $e) {
	header('Bad Request', true, 400);
    echo json_encode(array( 'error' => 1, 'message' => $e->getMessage() ));
}

?>