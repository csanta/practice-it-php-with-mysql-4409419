<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('./private/initialize.php');
require_once('./private/functions.php');

/*
if(!isset($_SESSION['access_token'])) {
	redirect_to(url_for('../google-login.php'));
	exit();	
}
 */

?>

<!--<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.js"></script>
<style type="text/css">
</style>
</head>

<body>-->

<?php include(SHARED_PATH . '/staff_header.php'); ?>

<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

	<div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
				    <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
				    <li><br></li>
				    <li><table style="width: 107px;">
					<tbody>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
					</tr>
			          <tr>
			          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
			          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
			          </tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
					</tr>
					</tbody>
					</table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			    <div id="frmToyCalendar">
					<iframe src="https://calendar.google.com/calendar/embed?height=100&amp;wkst=1&amp;bgcolor=%23ffffff&amp;ctz=America%2FLos_Angeles&amp;src=c2FudGEuY21AZ21haWwuY29t&amp;src=bWFwdTdzbnMzb2lzdnNqOGxwNmdtNTQzaHNAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbQ&amp;src=ZW4udXNhI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&amp;src=bTlkYTlxbWlzZmpuNXZlaDFpdjJjY3VoN2dvaTdxaDZAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=OTR2a3I3NGJkazA1M25kMzE2b2NpcTNyaXBvdmo1ZWtAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=dGJhbWlmMHZobmFsbzFvZ2g5cnNncjVlNHMyOGxpOXVAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=MmxvOXNhNmtwcW5pY3Rwbzd1cXRkbmxnbHRxYW81YXFAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=MWZkNjV0YnJpbGMwZDhpbzVlZnBmbmwzNzRnNG1jamVAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=ZWJwYTlmMnRvYzA0NWEyODYxbGlibmZpb2lma2VsdWpAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=OGppYzRxa3NiOWQ4ZnFtcGRuZjFoZ2czcHQ1Z2J2NGJAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=OTc1dWZwN2s4NTgwNjVtanMzNjRlaDAyanI0Z3RhbTlAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;src=Mm5vdTM0ZDBtNzlzNzJhcjBodmFxb2MxMDE3YjJqa3RAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;color=%23039BE5&amp;color=%237CB342&amp;color=%237986CB&amp;color=%237986CB&amp;color=%23F09300&amp;color=%23F4511E&amp;color=%23009688&amp;color=%233F51B5&amp;color=%23D81B60&amp;color=%23009688&amp;color=%23009688&amp;color=%238E24AA" style="border-width:0" width="100%" height="100%" frameborder="0" scrolling="no"></iframe>
				</div>
            </div>
        </div>
    </div>
</nav>

<?php
 include(SHARED_PATH . '/staff_footer.php'); 
?>
