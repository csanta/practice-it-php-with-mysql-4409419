<?php

/* Google App Client Id */
define('CLIENT_ID', '928169699334-eqgg0pu2a8ikljnl17rs5jplunqssesr.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'XVAa9P6IS_lkLuPGemLhV1AM');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost:80/29-1/google-login.php');

?>