<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');
require_once('../../private/functions.php');
require_once('../../private/gapi_credentials.php');
require_once('../../private/google_calendar_api.php');
require_once('../../private/html2pdf/tcpdf/examples/html2pdfapi.php');
require_once('email_headers.php');

/*
if(!isset($_SESSION['access_token'])) {
  header("Location: " . PROJECT_ROOT ."/google-login.php");
  exit(); 
}*/

$villas = array(
  array(
    "name" => "Rustica",
    "id" => 830
  ),
  array(
    "name" => "Tortuga",
    "id" => 826
  ),
  array(
    "name" => "Acqualina",
    "id" => 778
  ),
  array(
    "name" => "Solana",
    "id" => 752
  ),
);

$platforms = array(
  array(
    "name" => "Booking.com",
  ),
  array(
    "name" => "AirBnB.com",
  ),
  array(
    "name" => "VRBO.com",
  ),
  array(
    "name" => "Direct Carlos",
  ),
  array(
    "name" => "Direct Serge",
  ),
);

$villa_email_alias = "";
$welcome_packet_filename = "";
$db_table_name ="reservation";
$total_num_of_records = find_total_reservation_records($db_table_name);

if(!isset($_GET['id'])) {
  header("Location: " . PROJECT_ROOT ."public/reservations/search-modify-res.php");
}

$id = $_GET['id'];

if(is_post_request()) {

	// Handle form values sent by new.php
	$reservation = [];
	$reservation['id'] = $id;
	$reservation['first_name'] = $_POST['first_name'] ?? '';
	$reservation['last_name'] = $_POST['last_name'] ?? '';
	$reservation['email'] = $_POST['email'] ?? '';
	$reservation['street'] = $_POST['street'] ?? '';
	$reservation['city'] = $_POST['city'] ?? '';
	$reservation['state'] = $_POST['state'] ?? '';
	$reservation['zip'] = $_POST['zip'] ?? '';
	$reservation['phone'] = $_POST['phone'] ?? '';
	$reservation['platform'] = $_POST['platform'] ?? '';
	$reservation['check_in'] = $_POST['event-start-time'] ?? '';
	$reservation['check_out'] = $_POST['event-end-time'] ?? '';
	$reservation['total_guests'] = $_POST['total_guests'] ?? '';
	$reservation['villa_id'] = $_POST['event-villa-id'] ?? '';
	$reservation['villa_name'] = $_POST['event-villa-name'] ?? '';
	$reservation['guest_list'] = $_POST['guest_list'] ?? '';

	/* get the GAPI Calendar class stuff */
	$capi = new GoogleCalendarApi();

	/* Grab the GAPI calendar event ID */
	$gapi_calendar_event_id = find_gapi_calendar_event_by_id($id);

	/* Get user calendar timezone */
	if(!isset($_SESSION['user_timezone']))
	$_SESSION['user_timezone'] = $capi->GetUserCalendarTimezone($_SESSION['access_token']);

	$gapi_calendar_event_title = $reservation['villa_id']." - ".$reservation['villa_name']." - ".$reservation['first_name']." ".$reservation['last_name']." - #".$reservation['total_guests']." adults - ".$reservation['platform'];

	$event_start_time = $reservation['check_in']."T11:00:00";
	$temp_event_start_time = substr($event_start_time, 0, -9);
	$event_end_time = $reservation['check_out']."T11:00:00";
	$temp_event_end_time = substr($event_end_time, 0, -9);

	$event_location = $reservation['villa_name']." - Tortuga Properties Vacation Rental At Fairway Courts, Palmas Del Mar, 150 Candelero Dr, Humacao, 00791, Puerto Rico";
	$event_description = "Guest Name: ".$reservation['first_name']." ".$reservation['last_name']."\n".
	"Check-in: ".$temp_event_start_time."\n".
	"Check-out: ".$temp_event_end_time."\n".
	"Email: ".$reservation['email']."\n".
	"Phone: ".$reservation['phone']."\n".
	"Reservation ID: #".$reservation['id'];

	$event_color_id = "";

   if($reservation['villa_name'] == "Solana")
           $event_color_id = 5; /* Orange */
   else if($reservation['villa_name'] == "Acqualina")
           $event_color_id = 3; /* Purple */
   else if($reservation['villa_name'] == "Tortuga")
           $event_color_id = 11; /* Red */
   else
           $event_color_id = 9; /* Blue */
   /*
	* Update GAPI Event Calendar
	*/
	$beach_houses_cal_id = BEACH_HOUSES_GROUP_CALENDAR;
	$capi->UpdateCalendarEvent($gapi_calendar_event_id, $beach_houses_cal_id, $gapi_calendar_event_title, $event_description, $event_location, $event_color_id, $event_start_time, $event_end_time, $_SESSION['user_timezone'], $_SESSION['access_token']);

   /*
    * Grab previous packet_timestamp
    */
   $old_reservation = find_subject_by_id($id);
   $reservation['packet_timestamp'] = $old_reservation['packet_timestamp'];

	/*
	 * After the Google Calendar is updated then do the MySQL update...
	 */
	$result = update_reservation($reservation);

	$_SESSION['message'] = 'The reservation_id was updated successfully.';
	header("Location: " . PROJECT_ROOT ."/public/reservations/edit.php?id=" . $id);
	$message_to_user =  "message to user: ".$message_to_user;

}else {
	$reservation = find_subject_by_id($id);
	$reservation['id'] = $id;

	if( $reservation['total_guests'] >  0 ) {

			$email_subject = 'Welcome Packet from '.$reservation['villa_name']." Beach House - Palmas del Mar";
			$email_body = get_string_email_body($reservation);
			$auth_email_subject = 'Visitor Authorization Form for '.$reservation['first_name'].' '.$reservation['last_name'].' FWC #'.$reservation['villa_id'];
			$auth_email_body = get_string_auth_email_body($reservation);

			if($reservation['villa_name'] == "Solana") {
				$welcome_packet_filename = 'solana-welcome-package-2019-v2.pdf';
				$villa_email_alias = "rustica.fairwaycourts@gmail.com";
			}
			else if($reservation['villa_name'] == "Acqualina") {
				$welcome_packet_filename = 'acqualina-welcome-package-2019-v2.pdf';
				$villa_email_alias = "rustica.fairwaycourts@gmail.com";
			}
			else if($reservation['villa_name'] == "Tortuga") {
				$welcome_packet_filename = 'tortuga-welcome-package-2019-v2.pdf';
				$villa_email_alias = "rustica.fairwaycourts@gmail.com";
			}
			else {
				$welcome_packet_filename = 'rustica-welcome-package-2019-v2.pdf';
				$villa_email_alias = "rustica.fairwaycourts@gmail.com";
			}

			$welcome_packet_dir_path = PROJECT_ROOT . '/public/welcome_packets/en/'.$reservation['villa_id'].'/';
			$auth_form_dir_path = PROJECT_ROOT . '/public/authorization_forms/'.$reservation['villa_id'].'/';
			$auth_form_filename = $reservation['first_name'] . '_' . $reservation['last_name'] . '_' . $reservation['villa_id'] . '_' . $reservation['villa_name'] . '_' . $reservation['check_in'] . '_' . $reservation['check_out'] . '.pdf';
			/*
			 * Authorization Form
			 */
			$auth_form = new HTML2PDFApi();
			$todays_timestamp = time();
			$todays_timestamp = date("Y-m-d", $todays_timestamp);
			$auth_form->CreateNewAuthoForm($auth_form_filename, $reservation, $todays_timestamp);
	}
}

$reservation_set = find_all_subjects();
$subject_count = mysqli_num_rows($reservation_set);
mysqli_free_result($reservation_set);

?>

<?php $page_title = 'Edit Customer Reservation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<script>

$(document).on("click", "#send_email_button_modal", function(event){

	var reservation_id = <?php echo h($reservation['reservation_id']); ?>;

	parameters = {
		reservID: reservation_id,
		formID: 'welcome'
	};

	/* Show spinning wheel while we process */
	$("body").addClass('ajaxLoading');

	/* disable the submit button while we process */
	$("#send_email_button_modal").attr("disabled", true);

	$.ajax({
		type: "POST",
		url: 'send-email-ajax.php',
		data: { details: parameters },
		success: function(response) {
			console.log('Server: status : ' + response.status);
			console.log('Server: message: ' + response.message);
			console.log('Server: timestamp: ' + response.id);
			$('.modal.in').modal('hide');
			window.location.assign('http://www.rusticasoftware.com/villa_rental_webapp/29-1/public/reservations/edit.php?id=' + reservation_id);
		},
		error: function(response) {
			alert(response.responseJSON.message);
		}
	});

});

$(document).on("click", "#send_auth_email_button_modal", function(event){

	var reservation_id = <?php echo h($reservation['reservation_id']); ?>;

	parameters = {
		reservID: reservation_id,
		formID: 'authorization'
	};

	/* Show spinning wheel while we process */
	$("body").addClass('ajaxLoading');

	/* disable the submit button while we process */
	$("#send_auth_email_button_modal").attr("disabled", true);

	$.ajax({
		type: "POST",
		url: 'send-email-ajax.php',
		data: { details: parameters },
		success: function(response) {
			console.log('Server: status : ' + response.status);
			console.log('Server: message: ' + response.message);
			console.log('Server: timestamp: ' + response.id);
			$('.modal.in').modal('hide');
			window.location.assign('http://www.rusticasoftware.com/villa_rental_webapp/29-1/public/reservations/edit.php?id=' + reservation_id);
		},
		error: function(response) {
			alert(response.responseJSON.message);
		}
	});

});

</script>

<!--Begin Modal Window-->
<div class="modal fade left" id="myModalEmailPacket">
<div class="modal-dialog-form">
<div class="modal-content">

<div class="modal-body">

	<div id="frmEmail2">
	<h1><img src="<?php echo PROJECT_ROOT?>/public/images/paper_plane.png" alt="" width="48" height="48" align="center"/> Send Welcome Packet via Email</h1>
	<br>
	<dt>From:</dt>
		<input type="text" id="from_email" name="from_email" value="<?php echo h($villa_email_alias); ?>" autocomplete="off" />
	<dt>To:</dt>
		<input type="text" id="to_email" name="to_email" value="<?php echo h($reservation['email']); ?>" autocomplete="off" />
	<dt>Subject:</dt>
	<br>
		<input type="text" name="subject_email" value="<?php echo h($email_subject); ?>"><img src="<?php echo PROJECT_ROOT?>/public/images/paper-clip.png" alt="" width="16" height="16" /></input><a href="<?php echo h($welcome_packet_dir_path."/".$welcome_packet_filename);?>"><small> <?php echo h($welcome_packet_filename);?></a></small>
	<br>
	<dt>Message:</dt>
	<br><!-- rows=27 cols = 69-->
	<textarea style="resize:none" rows="8" cols="69" name="body_email" id="body_email"><?php echo h($email_body); ?></textarea>
	<br>
	<br>

	<button type="submit" id="send_email_button_modal" class="btn-submit btn btn-primary">Send Email</button>
	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	<br>
	<br>
	<small><strong>Last sent on :</strong><?php echo h($reservation['packet_timestamp']);?>
	</small>

	</div><!-- id="frmEmail2" -->

</div><!-- class="modal-body" -->

</div><!-- class="modal-content" -->
</div><!-- class="modal-dialog-form" -->
</div><!-- class="modal fade left" id="myModalEmailPacket" -->

<!--Begin Modal Window-->
<div class="modal fade left" id="myModalAuthForm">
<div class="modal-dialog-form">
<div class="modal-content">

<div class="modal-body">

	<div id="frmEmail2">
	<h1><img src="<?php echo PROJECT_ROOT?>/public/images/paper_plane.png" alt="" width="48" height="48" align="center"/> Send Authorization Form via Email</h1>
	<br>
	<dt>From:</dt>
		<input type="text" id="from_email" name="from_email" value="<?php echo h($villa_email_alias); ?>" autocomplete="off" />
	<dt>To:</dt>
		<input type="text" id="to_email" name="to_email" value="<?php echo h($reservation['email']); ?>" autocomplete="off" />
	<dt>Subject:</dt>
	<br>
		<input type="text" name="subject_email" value="<?php echo h($auth_email_subject); ?>"><img src="<?php echo PROJECT_ROOT?>/public/images/paper-clip.png" alt="" width="16" height="16" /></input>
		<a href="<?php echo h($auth_form_dir_path."/".$auth_form_filename);?>"><small><?php echo h($auth_form_filename);?></a></small>
	<br>
	<dt>Message:</dt>
	<br>
	<textarea style="resize:none" rows="8" cols="69" name="body_email" id="body_email"><?php echo h($auth_email_body); ?></textarea>
	<br>
	<br>

	<button type="submit" id="send_auth_email_button_modal" class="btn-submit btn btn-primary">Send Email</button>
	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	<br>
    <br>
	<small><strong>Last sent on :</strong>
	<?php echo h($reservation['packet_timestamp']);?>
	</small>

</div>

</div>

</div>
</div>
</div>


<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

	<div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
				    <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
				    <li><br></li>
				    <li><table style="width: 107px;">
					<tbody>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
					</tr>
					</tbody>
					</table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

<!-- division/nav -->
<div  class="frmToyEdit">
  

    <form name="frmToyEdit" id="frmToyEdit" enctype="multipart/form-data" action="<?php echo url_for('../public/reservations/edit.php?id=' . h(u($reservation['reservation_id']))); ?>" method="post">

    	<h1>Edit Reservation # <?php echo h($reservation['reservation_id']); ?></h1>
    	<br>

      <dl>
        <dt>First Name:</dt>
        <dd><input style="width: 550px;" type="text" name="first_name" class="demoInputBox" value="<?php echo h($reservation['first_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Last Name:</dt>
        <dd><input style="width: 550px;" type="text" name="last_name" class="demoInputBox" value="<?php echo h($reservation['last_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Email</dt>
        <dd><input style="width: 550px;" type="text" name="email" class="demoInputBox" value="<?php echo h($reservation['email']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Street:</dt>
        <dd><input style="width: 550px;" type="text" name="street" class="demoInputBox" value="<?php echo h($reservation['street']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>City:</dt>
        <dd><input style="width: 550px;" type="text" name="city" class="demoInputBox" value="<?php echo h($reservation['city']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>State:</dt>
        <dd><input style="width: 550px;" type="text" name="state" class="demoInputBox" value="<?php echo h($reservation['state']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Zip:</dt>
        <dd><input style="width: 550px;" type="text" name="zip" class="demoInputBox" value="<?php echo h($reservation['zip']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Phone:</dt>
        <dd><input style="width: 550px;" type="text" name="phone" class="demoInputBox" value="<?php echo h($reservation['phone']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
		<dt>Booking Platform:</dt>
		<dd><select style="width: 550px;" id="platform" name="platform"  autocomplete="off">
	          <?php
	            foreach ($platforms as $key => $val) {
	              echo "<option value=\"{$platforms[$key]["name"]}\"";
	              if($platforms[$key]["name"] == $reservation['platform']) {
	                echo " selected";
	              }
	              echo ">{$platforms[$key]["name"]}</option>";
	            }
	          ?>
		</select>
		</dd>
	</dl>
	<dl>
	<dt>Check in:</dt>
	<dd><input style="width: 550px;" type="text" id="event-start-time" name="event-start-time" value="<?php echo h($reservation['check_in']); ?>" autocomplete="off" />
	</dd>
	</dl>
	<dt>Check out:</dt>
	<dd><input style="width: 550px;" type="text" id="event-end-time" name="event-end-time" value="<?php echo h($reservation['check_out']); ?>" autocomplete="off" />
	</dd>
      <dl>
      <dl>
        <dt>Total num of guests:</dt>
        <dd><input style="width: 550px;" type="text" name="total_guests" class="demoInputBox" value="<?php echo h($reservation['total_guests']); ?>" /></dd>
      </dl>
      <dl>
	<dt>Name of Guests:</dt>
	<br>
	<dd><textarea style="width: 550px; resize:none" rows="3" cols="72" name="guest_list" id="guest_list"><?php echo h($reservation['guest_list']); ?></textarea>
	</dd>
    </dl>
	<dl>
	<br>
	<dt>Villa name:</dt>
	<dd><select style="width: 550px;" id="event-villa-name"  name="event-villa-name" autocomplete="off">
          <?php
            foreach ($villas as $key => $val) {
           	  $count = 0;
              echo "<option value=\"{$villas[$key]["name"]}\"";
              if($villas[$key]["name"] == $reservation['villa_name']) {
                echo " selected";
              }
              echo ">{$villas[$key]["name"]}</option>";
            }
          ?>
	</select>
    </dd>
	</dl>
    <dl>
	<dt>Villa ID #:</dt>
	<dd><select style="width: 550px;" id="event-villa-id" name="event-villa-id"  autocomplete="off">
          <?php
            foreach ($villas as $key => $val) {
              echo "<option value=\"{$villas[$key]["id"]}\"";
              if($villas[$key]["id"] == $reservation['villa_id']) {
                echo " selected";
              }
              echo ">{$villas[$key]["id"]}</option>";
            }
          ?>
	</select>
	</dd>
    </dl>
    <div style="text-align: center;">
		<button type="submit" name="commit" class="btn-submit btn btn-primary">Save Reservation</button>
    </div>
<p>
<br>
<br>
<br>

<div id="frmPacket">
<table style="width: 700px; height: 69px;">
<tbody>
<tr style="height: 32px;">
<td style="width: 112.9px; height: 32px;">
<h1><img src="<?php echo PROJECT_ROOT?>/public/images/email-circle.png" alt="" width="48" height="48" /></h1>
</td>
<td style="width: 559.1px; height: 32px;">
	<h1>Guests Welcome Packet</h1>
	<div class="pull-left" style="text-align: left;">
		<?php
		echo "<p><strong>Last sent:</strong> "; echo h($reservation['packet_timestamp']);
		echo "</p>";
		?>
	</div>
</td>
<td style="width: 86.0px; height: 32px;">
<div class="pull-right" style="text-align: right;"><button class="btn-submit btn btn-primary" type="button" data-toggle="modal" data-target="#myModalEmailPacket">Send Me</button></div>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<p>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div id="frmAuth">

<table style="width: 700px; height: 69px;">
<tbody>
<tr style="height: 32px;">
<td style="width: 112.9px; height: 32px;">
<h1><img src="<?php echo PROJECT_ROOT?>/public/images/email-circle.png" alt="" width="48" height="48" /></h1>
</td>
<td style="width: 559.1px; height: 32px;">
	<h1>Security Guards Authorization Form</h1>
	<div class="pull-left" style="text-align: left;">
		<?php
		echo "<p><strong>Last sent:</strong> "; echo h($reservation['packet_timestamp']);
		echo "</p>";
		?>
	</div>
</td>
<td style="width: 86.0px; height: 32px;">
<div class="pull-right" style="text-align: right;"><button class="btn-submit btn btn-primary" type="button" data-toggle="modal" data-target="#myModalAuthForm">Send Me</button></div>
</td>
</tr>
</tbody>
</table>
</div>
</div>

</form>
<br>
<br>

<!-- division/nav -->

            </div>
        </div>
    </div>
</nav>






<script>

// Selected time should not be less than current time
function AdjustMinTime(ct) {
	var dtob = new Date(),
  		current_date = dtob.getDate(),
  		current_month = dtob.getMonth() + 1,
  		current_year = dtob.getFullYear();

	var full_date = current_year + '-' +
					( current_month < 10 ? '0' + current_month : current_month ) + '-' +
		  			( current_date < 10 ? '0' + current_date : current_date );

	if(ct.dateFormat('Y-m-d') == full_date)
		this.setOptions({ minTime: 0 });
	else
		this.setOptions({ minTime: false });
}
/* Note: DateTimePicker plugin : http://xdsoft.net/jqplugins/datetimepicker
 * Example: format: 'Y-m-d H:i'
 */
$("#event-start-time, #event-end-time").datetimepicker({ format: 'Y-m-d', minDate: 0, minTime: 0, step: 5, onShow: AdjustMinTime, onSelectDate: AdjustMinTime });
</script>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
