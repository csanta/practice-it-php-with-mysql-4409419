<?php

/*
 * Carlos Santa Copyright (c) 2019 santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

function get_string_email_body($reservation) {

	$email_body = '
 Hello '.$reservation[first_name].'!'.'

 Please find in the attachment your welcome packet to your rental. It has a lot of information about how to operate the villa including how to get the keys as well as additional info on the surrounding areas in Palmas del Mar.

 The '.$reservation['villa_name'].' villa is located within the Fairway Courts complex, unit #'.$reservation[villa_id].'

 The address is:

 Palmas del Mar
 Fairway Courts Complex
 150 Candelero Drive Unit# '.$reservation[villa_id].'
 Humacao, PR, 00791
 Google Map: https://goo.gl/maps/czGusypQ7CR2

 Check in: '.$reservation['check_in'].'
 Check out: '.$reservation['check_out'].'

 Let us know if you have any questions.

 Carlos Santa
 939-529-1552


 PS. Please, water our plants. ';

return $email_body;

}

function get_html_email_body($reservation){
$email_body = '
Hello '.$reservation[first_name].'!'.'</br>

<p>Please find in the attachment your welcome packet to your rental. It has a lot of information about how to operate the villa including how to get the keys as well as additional info on the surrounding areas in Palmas del Mar.

<p>The '.$reservation['villa_name'].' villa is located within the Fairway Courts complex, unit #'.$reservation[villa_id].'

<p>The address is:

<p>Palmas del Mar<br>
Fairway Courts Complex<br>
150 Candelero Drive Unit# '.$reservation[villa_id].'<br>
Humacao, PR, 00791<br>
Google Map: https://goo.gl/maps/czGusypQ7CR2

<p>Check in: '.$reservation['check_in'].'<br>
Check out: '.$reservation['check_out'].'

<p>Let us know if you have any questions.

 <p>Carlos Santa<br>
 939-529-1552


<br>PS. Please, water our plants. ';

return $email_body;
}

function get_string_auth_email_body($reservation) {

	$email_body = '
 Hello Rose/April!'.'

 Please find in the attachment the visitor authorization form for ' . $reservation['first_name'] .' '. $reservation['last_name'] . ' who is staying at villa FWC #'.$reservation['villa_id'].'

 Check in: '.$reservation['check_in'].'
 Check out: '.$reservation['check_out'].'

 Thanks,

  Carlos Santa
  939-529-1552

';

return $email_body;

}

function get_html_authorization_email_body($reservation){
$email_body = '
Hello Rose/April!'.'</br>

<p>Please find in the attachment the visitor authorization form for ' . $reservation['first_name'] .' '. $reservation['last_name'] . ' who is staying at villa FWC #'.$reservation['villa_id'].'

<p>Check in: '.$reservation['check_in'].'<br>
Check out: '.$reservation['check_out'].'

<p>Thanks,

 <p>Carlos Santa<br>
 939-529-1552

';

return $email_body;
}

?>