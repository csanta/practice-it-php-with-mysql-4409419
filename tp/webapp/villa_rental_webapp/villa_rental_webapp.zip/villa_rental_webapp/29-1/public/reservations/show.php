<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');

/*
if(!isset($_SESSION['access_token'])) {
  redirect_to(url_for('../google-login.php'));
  exit(); 
}
 */

$id = $_GET['id'] ?? '1'; // PHP > 7.0

$reservation = find_subject_by_id($id);

?>

<?php $page_title = 'Show Customer Reservation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content" class="frmToy">
  <a class="back-link" href="<?php echo url_for('../public/reservations/search-modify-res.php'); ?>">&laquo; Back to List</a>

<h1>View Reservation</h1>

    <form name="frmToy" method="post" action="" id="frmToy" action="<?php echo url_for('/staff/subjects/new.php'); ?>" method="post">
      <dl>
        <dt>First Name:</dt>
        <dd><input type="text" name="first_name" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['first_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Last Name:</dt>
        <dd><input type="text" name="last_name" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['last_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Email</dt>
        <dd><input type="text" name="email" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['email']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Street:</dt>
        <dd><input type="text" name="street" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['street']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>City:</dt>
        <dd><input type="text" name="city" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['city']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>State:</dt>
        <dd><input type="text" name="state" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['state']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Zip:</dt>
        <dd><input type="text" name="zip" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['zip']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Phone:</dt>
        <dd><input type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['phone']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Booking Platform:</dt>
        <dd><input type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['platform']); ?>" /></dd>
      </dl>
      <dl>  
      <dl>
        <dt>Check in:</dt>
        <dd><input type="text" id="datepicker" name="check_in" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['check_in']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Check out:</dt>
        <dd><input type="text" id="checkout_datepicker" name="check_out" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['check_out']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Total num of guests:</dt>
        <dd><input type="text" name="total_guests" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['total_guests']); ?>" /></dd>
      </dl>
      <dl>                         
      <dl>
        <dt>Villa Name:</dt>
        <dd><input type="text" id="datepicker" name="check_in" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['villa_name']); ?>" /></dd>
      </dl>   
      <dl>                                           
      <dl>
        <dt>Villa ID:</dt>
        <dd><input type="text" id="datepicker" name="check_in" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['villa_id']); ?>" /></dd>
      </dl>   
      <dl>  
      </dl>
      <dl>
        <dt>Visible</dt>
        <dd>
          <input type="hidden" name="visible" value="0" />
          <input type="checkbox" name="visible" value="1"<?php if($reservation['visible'] == 1) { echo " checked"; } ?> />
        </dd>
      </dl>
    </form>

    
