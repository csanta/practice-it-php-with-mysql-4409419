<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

session_start();
header('Content-type: application/json');

require_once('../../private/initialize.php');
require_once('../../private/functions.php');
require_once('../../private/gapi_credentials.php');
require_once('../../private/google_calendar_api.php');

if(!isset($_SESSION['access_token'])) {
	redirect_to(url_for('../../google-login.php'));
	exit();
}

try {
	/* Get event details */
	$output = array( 'id' => null, 'status' => 'false', 'message' => null);

	$id = $_POST['res'];

	/* get the GAPI Calendar class stuff */
	$capi = new GoogleCalendarApi();

	/* Grab the GAPI calendar event ID */
	$gapi_calendar_event_id = find_gapi_calendar_event_by_id($id);

	if ($gapi_calendar_event_id != NULL) {

		$beach_houses_cal_id = BEACH_HOUSES_GROUP_CALENDAR;

		/* Delete event on primary calendar */
		$capi->DeleteCalendarEvent($gapi_calendar_event_id, $beach_houses_cal_id, $_SESSION['access_token']);

		/* Delete the reservation entry as well on the MySQL DB */
		$result = delete_reservation_with_gapi_id($gapi_calendar_event_id);

		if ($result === true) {
			$output["status"] = 'true';
			$output["message"] = 'The reservation with id='.$id.' was deleted successfully.';
		} else {
			$output["status"] = 'false';
			$output["message"] = 'The reservation with id='.$id.' was note deleted.';
		}

	} else { /* Older reservations have no GAPI id */

		$result = delete_reservation_with_id($id);

		if ($result === true) {
			$output["status"] = 'true';
			$output["message"] = 'The reservation with id='.$id.' was deleted successfully.';
		} else {
		  $output["status"] = 'false';
		  $output["message"] = 'The reservation with id='.$id.' was note deleted.';
		}
	}
	echo json_encode($output);

}
catch(Exception $e) {
	header('Bad Request', true, 400);
    echo json_encode(array( 'error' => 1, 'message' => $e->getMessage() ));
}

?>