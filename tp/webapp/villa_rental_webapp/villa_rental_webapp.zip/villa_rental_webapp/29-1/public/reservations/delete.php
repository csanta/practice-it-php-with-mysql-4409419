<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');
require_once('../../private/functions.php');
require_once('../../private/google_calendar_api.php');

if(!isset($_SESSION['access_token'])) {
  header("Location: " . PROJECT_ROOT ."/google-login.php");
  exit();
}

if(!isset($_GET['id'])) {
  header("Location: " . PROJECT_ROOT ."public/reservations/search-modify-res.php");
}
$id = $_GET['id'];

/* Grab the reservation ID so that we can show it in the current page */
$reservation = find_subject_by_id($id);

?>
<?php $page_title = 'Delete Reservation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<script>
$(document).on("click", "#delete_reservation", function(event){

  var reservation_id = $("#res_id").val();

  $.ajax({
      type: "POST",
      url: 'delete-ajax.php',
      data: {res: reservation_id},
      success: function(response){
            if(response.status==='true') {
              $('.modal.in').modal('hide');
                console.log('Server: status : ' + response.status);
                console.log('Server: Message: ' + response.message);
                window.location.assign('http://www.rusticasoftware.com/villa_rental_webapp/29-1/public/reservations/search-modify-res.php');

            } else {
                console.log('Server: status' + response.status);
                console.log('Server: Message: ' + response.message);
            }
      },
      error: function(response) {
        alert(response.responseJSON.message);
      }
  });

});

</script>

  <!-- Delete Popup Window Modal -->
<div class="modal fade" id="myModal" name="popupbox" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" title="Close"><span class="glyphicon glyphicon-remove"></span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Reservation # <?php echo h($reservation['reservation_id']); ?></h4>
      </div>
      <div class="modal-body text-blue">
        <h3>Warning! Are you sure you want to delete this reservation?</h3>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" id="delete_reservation" class="btn-submit btn btn-danger">Delete</button>
      </div>
    </div>
  </div>
</div>


<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

	<div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
				    <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
				    <li><br></li>
				    <li><table style="width: 107px;">
					<tbody>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
          </tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
					</tr>
					</tbody>
					</table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

<!-- division/nav -->
<div class="frmToyDelete">

    <form id="frmToyDelete" action="<?php echo url_for('../public/reservations/delete.php?id=' . h(u($reservation['reservation_id']))); ?>" method="post">

      <h1>Delete Reservation # <?php echo h($reservation['reservation_id']); ?></h1>
    	<br>

      <dl>
        <dt>First Name:</dt>
        <dd><input style="width: 550px;" type="text" name="first_name" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['first_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Last Name:</dt>
        <dd><input style="width: 550px;" type="text" name="last_name" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['last_name']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Email</dt>
        <dd><input style="width: 550px;" type="text" name="email" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['email']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Street:</dt>
        <dd><input style="width: 550px;" type="text" name="street" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['street']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>City:</dt>
        <dd><input style="width: 550px;" type="text" name="city" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['city']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>State:</dt>
        <dd><input style="width: 550px;" type="text" name="state" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['state']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Zip:</dt>
        <dd><input style="width: 550px;" type="text" name="zip" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['zip']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Phone:</dt>
        <dd><input style="width: 550px;" type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['phone']); ?>" /></dd>
      </dl>
      <dl>
      </dl>
    <dl>
    <dt>Booking site:</dt>
    <dd><input style="width: 550px;" type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['platform']); ?>" /></dd>
  </dl>
    <dl>
      </dl>
    <dl>
    <dt>Check in:</dt>
    <dd><input style="width: 550px;" type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['check_in']); ?>" /></dd>
  </dl>
  <dl>
  </dl>
    <dl>
    <dt>Check out:</dt>
    <dd><input style="width: 550px;" type="text" name="phone" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['check_out']); ?>" /></dd>
  </dl>
      <dl>
      <dl>
        <dt>Total num of guests:</dt>
        <dd><input style="width: 550px;" type="text" name="total_guests" class="demoInputBox" disabled="disabled" value="<?php echo h($reservation['total_guests']); ?>" /></dd>
      </dl>
      <dl>
      <dl>
        <dt>Villa Name:</dt>
        <dd><input style="width: 550px;" type="text" id="villa_name" name="villa_name" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['villa_name']); ?>" /></dd>
      </dl>
      <dl>
      </dl>
      <dl>
        <dt>Villa ID:</dt>
        <dd><input style="width: 550px;" type="text" id="villa_id" name="villa_id" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['villa_id']); ?>" /></dd>
      </dl>
      <dl>
      </dl>
      <dl>
        <dt>Reservation ID:</dt>
        <dd><input style="width: 550px;" type="text" id="res_id" name="reservation_id" disabled="disabled" class="demoInputBox" value="<?php echo h($reservation['reservation_id']); ?>" /></dd>
      </dl>
      <div style="text-align: center;">
        <button type="button" class="btn-submit btn btn-primary" data-toggle="modal" data-target="#myModal">
        Delete Reservation
        </button>
      </div>
</form>

<!-- division/nav -->

            </div>
        </div>
    </div>
</nav>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
