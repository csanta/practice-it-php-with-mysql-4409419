$(document).ready(function(){
	/* handling form validation */
	$("#login-form").validate({
		rules: {
			password: {
				required: true,
			},
			username: {
				required: true,
				email: true
			},
		},
		messages: {
			password:{
			  required: "Please enter your password"
			  //console.log('#someButton was clicked');
			 },
			username: "Please enter your email address",
		},
		submitHandler: submitForm	
	});	

	/* Handling login functionality */
	function submitForm() {		
		var data = $("#login-form").serialize();
		$.ajax({				
			type : 'POST',
			url  : 'response.php?action=login',
			data : data,
			beforeSend: function(){	
				$("#error").fadeOut();
				$("#login_button").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...!');
			},
			success : function(response){			
				if($.trim(response) === "1"){
					//printf("%s %d\n",__FUNCTION__,__LINE__);
					//echo "ddddd";
					//console.log('dddd');									
					$("#login-submit").html('Signing In ...');
					setTimeout('window.location.href = "dashboard.php";',20);
				} else {	
				    //console.log('dddd');
				    //echo "failed!!";								
					$("#error").fadeIn(1000, function(){						
						$("#error").html(response).show();
					});
				}
			}
		});
		return false;
	}

	/* Handling login functionality */
	function logout() {
		//console.log('fdfdf');
		$.ajax({				
			type : 'POST',
			url  : 'response.php?action=logout',
			data : data,
			success : function(response){
				window.location.href = "/index.php";
			}
		});
		return false;
	}   
});