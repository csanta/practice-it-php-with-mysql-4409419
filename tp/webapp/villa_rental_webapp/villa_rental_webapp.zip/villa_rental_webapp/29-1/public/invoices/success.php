<?php
/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');
require_once('../../private/functions.php');

if(!empty($_GET['tid'] && !empty($_GET['product']))) {

	$tid = $_GET['tid'];
	$product = $_GET['product'];
} else {
	header("Location: " . PROJECT_ROOT ."/public/invoices/search-modify-inv.php");
}

?>

<?php $page_title = 'Success'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

  <h1><img src="<?php echo PROJECT_ROOT?>/public/images/paper_plane.png" alt="" width="48" height="48" align="center"/> Pay Invoice</h1>

  <div class="container.mt-4">
  	<h2>Thank you for purchasing <?php echo $product; ?></h2>
  	<hr>
  	<p>Your transaction ID is <?php echo $tid; ?></p>
  	<p>Check your email for more info</p>
  	<p><a href="search-modify-inv.php" class="btn btn-light mt-2">Go Back</a></p>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>