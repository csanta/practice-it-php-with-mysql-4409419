<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');
require_once('../../private/functions.php');
require_once('../../private/google_calendar_api.php');

/*
if(!isset($_SESSION['access_token'])) {
  header("Location: " . PROJECT_ROOT ."/google-login.php");
  exit();
}
 */

  /* Debugging */
  $errors = [];
  $id = $_GET['id'];

  /* Figure out the invoice id # for a new order */
  $invoice_order_no = find_new_order_id();
  $order_no = $invoice_order_no + 1;
  //$errors[0].="order_no: ".$order_no;

  if (isset($_POST["create_invoice"])) { 

    /* iterator used to figure out how many total rows any given
     * invoice have, recall that invoices can have N number of
     * rows (i.e., rent, cleaning, commission, etc)
     */ 
    $order_row_id_count = trim($_POST["total_item"]);

    /* Most of these parameters are arrays because
     * again, invoices can N number of rows
     */
    $order_item_name[$order_row_id_count];
    $order_item_quantity[$order_row_id_count];
    $order_item_price[$order_row_id_count];
    $order_item_amount[$order_row_id_count];
    $order_tax_rate[$order_row_id_count];
    $order_tax_rate_amount[$order_row_id_count];
    $order_item_final_amount[$order_row_id_count];

    $order_receiver_name = $_POST["order_receiver_name"];
    $order_receiver_address = $_POST["order_receiver_address"];
    $order_receiver_phone = "14695697081";
    $order_receiver_email = "santa.cm@gmail.com";
    $order_date = "2019-09-11";//$_POST["order_date"];
    $order_due_date = "2019-09-11";//$_POST["order_due_date"];

    for ($i = 0; $i < $order_row_id_count; $i++) {
      $order_item_name[$i] = trim($_POST["order_item_name"][$i]);
      $order_item_quantity[$i] = trim($_POST["order_item_quantity"][$i]);
      $order_item_price[$i] = trim($_POST["order_item_price"][$i]);
      $order_item_amount[$i] = trim($_POST["order_item_amount"][$i]);
      $order_tax_rate[$i] = trim($_POST["order_tax_rate"][$i]);
      $order_tax_rate_amount[$i] = trim($_POST["order_tax_rate_amount"][$i]);
      $order_item_final_amount[$i] = trim($_POST["order_item_final_amount"][$i]);
      $order_total += trim($order_item_final_amount[$i]);
    }
    $order_total_pretax = trim($_POST["order_total_pretax"]);
    $order_total_tax_amount = trim($_POST["order_total_tax_amount"]);

      /*$sql .= "(order_no,order_receiver_name,order_receiver_address,order_receiver_email,order_receiver_phone,order_date,order_due_date,order_item_name,order_item_quantity,order_item_price,order_item_amount,order_tax_rate,order_tax_rate_amount,order_item_final_amount,order_total_pretax,order_total_tax_amount,order_total,order_row_id_count) ";*/
    $invoice_arr = [];

    /*
     * We insert all the invoice data as well as the contact info into a dynamic 2D associative array
     * where all the rows belonging to the same order can then be sorted using "order_no" as the
     * primary sorting key
     */
    for ( $i = 0; $i < $order_row_id_count; $i++ ) {
        $invoice_arr[ $i ] = array(
            "$i" => array($order_no, $order_receiver_name, $order_receiver_address, $order_receiver_email, $order_receiver_phone, $order_date, $order_due_date, $order_item_name[$i], $order_item_quantity[$i], $order_item_price[$i], $order_item_amount[$i], $order_tax_rate[$i], $order_tax_rate_amount[$i], $order_item_final_amount[$i], $order_total_pretax, $order_total_tax_amount, $order_total, $order_row_id_count)
        );
    }

    /*
     * Finally, send the invoice array for insertion into MySQL
     */
    $result = insert_invoice($invoice_arr);

   //header("Location: ./invoice-edit.php?add=".$order_row_id_count);

  $errors[1].="order_receiver_name: ".$order_receiver_name;
  $errors[2].="order_receiver_address: ".$order_receiver_address;
  $errors[3].="order_receiver_email: ".$order_receiver_email;
  $errors[4].="order_receiver_phone: ".$order_receiver_phone;
  $errors[5].="order_date: ".$order_date;
  $errors[5].="order_due_date: ".$order_due_date;
  $errors[6].="order_item_name: ".$order_item_name[0];
  $errors[7].="order_item_quantity: ".$order_item_quantity[0];
  $errors[8].="order_item_amount: ".$order_item_amount[0];
  $errors[9].="order_tax_rate: ".$order_tax_rate[0];
  $errors[10].="order_tax_rate_amount: ".$order_tax_rate_amount[0];
  $errors[11].="order_item_final_amount : ".$order_item_final_amount[0];
  $errors[12].="order_total_pretax : ".$order_total_pretax;
  $errors[13].="order_total_tax_amount : ".$order_total_tax_amount;
  }

?>
<?php $page_title = 'Edit Reservation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>


<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

  <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
            <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
            <li><br></li>
            <li><table style="width: 107px;">
          <tbody>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
          </tr>                    
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
          </tr>
          </tbody>
          </table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main"> 

<!-- division/nav -->


<div id="content">

<div class="row box" id="login-box">
                <?php echo display_errors($errors); ?>
  <div class="col-sm-14 col-sm-offset-14">
    <div class="panel panel-login">
      <div class="alert ">

<form method="post" id="invoice_form">
<table style="width: 811px; height: 173px;">
<tbody>
<tr>
<td style="width: 180px;">
<p style="text-align: left;"><img class="center" src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" alt="Rustica" width="136" height="136" /></p>
</td>
<td style="width: 408.983px;">&nbsp;</td>
<td style="width: 199.017px; text-align: right;"><strong>Tortuga Properties</strong><br /> 150 Candelero Drive<br /> APT 826<br /> Humacao 00791<br /> Puerto Rico<br /> 939-529-1552</td>
</tr>
</tbody>
</table>
<hr />
<table style="width: 813px;" border="0">
<tbody>
<tr>
<td style="width: 172.367px;">
<table>
<tbody>
<tr>
<td><strong>Bill To:</strong></td>
<td><input class="demoInputBox" style="width: 232px; padding: 4px 4px;" name="order_receiver_name" type="text" value="Guest Name" /></td>
</tr>
<tr>
<td><strong>Address To:</strong></td>
<td><textarea style="width: 240px; resize:none" rows="3" cols="72" name="order_receiver_address" id="order_receiver_address" > 911 SW 21ST Ave</textarea></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width: 53.6333px;">&nbsp;</td>
<td style="width: 10px; text-align: right;"><strong><br /> </strong>
<table style="height: 128px; width: 355px;" border="0" align="right">
<tbody>
<tr style="height: 18px;">
<td style="width: 249.317px; height: 18px; text-align: right; padding: 0px 0px;"><strong>Invoice Num:</strong></td>
<td style="width: 89.6833px; height: 18px; text-align: left; padding: 4px 8px;"><input class="demoInputBox" style="width: 100px; padding: 4px 4px; text-align: center;" disabled="disabled" name="last_name" type="text" value="<?php echo h($order_no); ?>" /></td>
</tr>
<tr style="height: 18px;">
<td style="width: 249.317px; height: 18px; text-align: right; padding: 0px 0px;"><strong>Invoice Date:</strong></td>
<td style="width: 89.6833px; height: 18px; text-align: left; padding: 4px 8px;"><input class="demoInputBox" style="width: 100px; padding: 4px 4px;" name="order_date" id="order_date" type="text" value="09/11/2019" /></td>
</tr>
<tr style="height: 18px;">
<td style="width: 249.317px; height: 18px; text-align: right; padding: 0px 0px;"><strong>Payment Due:</strong></td>
<td style="width: 89.6833px; height: 18px; text-align: left; padding: 4px 8px;"><input class="" style="width: 100px; padding: 4px 4px;" name="order_due_date" id="order_due_date" type="text" value="09/13/2019" /></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

<br>
        <div class="table-responsive">
          <table class="table ">

            <tr>
   
                  <br />
                  <table id="invoice-item-table" class="table table-hover table-striped table-" style="margin-bottom:0px">
                    <tr>
                      <th style="width: 4%; text-align: center; background-color: #e84353; color: white;">#</th>
                      <th style="width: 19%; text-align: center; background-color: #e84353; color: white;">Items</th>
                      <th style="width: 8%; text-align: center; background-color: #e84353; color: white;">Quantity</th>
                      <th style="width: 5%; text-align: center; background-color: #e84353; color: white;">Price</th>
                      <th style="width: 2%; text-align: center; background-color: #e84353; color: white;">Amount</th>
                      <th style="width: 11.5%; text-align: center; background-color: #e84353; color: white;" colspan="2">Room Tax (%)</th>
                      <th style="width: 6.5%; text-align: center; background-color: #e84353; color: white;" rowspan="1">Total</th>
                      <th style="width: 9%; text-align: center; background-color: #e84353; color: white;" rowspan="1"><div align="center"><button id="add_row" class="btn btn-success btn-s" name="add_row" type="button"><i class="glyphicon glyphicon glyphicon-plus-sign"></i></button></div></th>
                    </tr>
                    <tr>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th>Rate</th>
                      <th>Amt.</th>
                      <th></th>
		      <th></th>
                    </tr>
                    <tr>
                      <td><span id="sr_no" name="row_id_count">1</span></td>
                      <td><input style="width: 230px; text-align: center;font-weight: bold;" type="text" name="order_item_name[]" id="order_item_name1" class="form-control input-sm" value="Rent"/></td>
                      <td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_quantity[]" id="order_item_quantity1" data-srno="1" class="form-control input-sm order_item_quantity" value="1" /></td>
                      <td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_price[]" id="order_item_price1" data-srno="1" class="form-control input-sm number_only order_item_price" value="189"/></td>
                      <td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_amount[]" id="order_item_amount1" data-srno="1" class="form-control input-sm order_item_amount" readonly /></td>
                      <td><input style="width: 40px; text-align: center;font-weight: bold;" type="text" name="order_tax_rate[]" id="order_tax_rate1" data-srno="1" class="form-control input-sm number_only order_tax_rate" value="7"/></td>
                      <td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_tax_rate_amount[]" id="order_tax_rate_amount1" data-srno="1" readonly class="form-control input-sm order_tax_rate_amount" /></td>

                      <td><input style="width: 60px; text-align: center; font-weight: bold;" type="text" name="order_item_final_amount[]" id="order_item_final_amount1" data-srno="1" readonly class="form-control input-sm order_item_final_amount" /></td>
                      <td><button type="button " disabled name="remove_row" class="btn btn-danger btn-s remove_row"><i class="glyphicon glyphicon glyphicon-minus-sign"></i></button></td>
                    </tr>
                  </table>
<table style="width: 360px;" align="right" border="0" class="table table-hover table-">
<tbody>
<tr>
<td style="width: 195.0px; text-align: right;"><div align="left"><strong>Subtotal:</strong></div></td>
<td style="width: 1.35px; text-align: right;"><strong>$<span name="order_item_subtotal_pretax" id="order_item_subtotal_pretax"></span><input id="order_total_pretax" name="order_total_pretax" type="hidden" value="" /></strong></td>
</tr>
<tr>
<td style="width: 195.0px; text-align: right;"><div align="left"><strong>Room Tax(<span id="tax_rate"></span>%):</strong></div></td>
<td style="width: 1.35px; text-align: right;"><strong>$<span id="final_total_tax_amt"></span><input id="order_total_tax_amount" name="order_total_tax_amount" type="hidden" value="" /></strong></td>
</tr>
<tr>
<td style="width: 195.0px; text-align: right; background-color: #E8E8E8;"><div align="left"><strong>Total Due:</strong></div></td>
<td style="width: 1.35px; text-align: right; background-color: #E8E8E8;"><strong>$<span id="final_total_amt"></span></strong></td>
</tr>

<tr>
<td style="width: 1.65px;" colspan="1" align="left"><input id="total_item" name="total_item" type="hidden" value="1" /></td>
<td style="width: 195.0px; text-align: right;"></td>
</tr>
</tbody>
</table>
        </div>
        <br><br><br>
        <div align="center"><input id="create_invoice" class="btn btn-info" name="create_invoice" type="submit" value="Create Inovice" /></div>
      </form>

      <script>
      $(document).ready(function(){

        var final_total_amt = $('#final_total_amt').text();
        var final_total_tax_amt = $('#final_total_tax_amt').text();
        var count = 1;
        $('#tax_rate').text($('#order_tax_rate'+1).val());
        
        
        $(document).on('click', '#add_row', function(){
          count++;
          $('#total_item').val(count);
          
          var html_code = '';
          html_code += '<tr id="row_id_'+count+'" name="row_id_count">';
          html_code += '<td><span id="sr_no">'+count+'</span></td>';
          
          html_code += '<td><input style="width: 230px; text-align: center;font-weight: bold;" type="text" name="order_item_name[]" id="order_item_name'+count+'" class="form-control input-sm" value="Rent 1 Night"/></td>';
          
          html_code += '<td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_quantity[]" id="order_item_quantity'+count+'" data-srno="'+count+'" class="form-control input-sm number_only order_item_quantity" /></td>';
          html_code += '<td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_price[]" id="order_item_price'+count+'" data-srno="'+count+'" class="form-control input-sm number_only order_item_price" /></td>';
          html_code += '<td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_item_amount[]" id="order_item_amount'+count+'" data-srno="'+count+'" class="form-control input-sm order_item_amount" readonly /></td>';
          
          html_code += '<td><input style="width: 40px; text-align: center;font-weight: bold;" type="text" name="order_tax_rate[]" id="order_tax_rate'+count+'" data-srno="'+count+'" class="form-control input-sm number_only order_tax_rate" /></td>';
          html_code += '<td><input style="width: 50px; text-align: center;font-weight: bold;" type="text" name="order_tax_rate_amount[]" id="order_tax_rate_amount'+count+'" data-srno="'+count+'" readonly class="form-control input-sm order_tax_rate_amount" /></td>';
          html_code += '<td><input style="width: 60px; text-align: center; font-weight: bold;" type="text" name="order_item_final_amount[]" id="order_item_final_amount'+count+'" data-srno="'+count+'" readonly class="form-control input-sm order_item_final_amount" /></td>';
          html_code += '<td><button type="button" name="remove_row" id="'+count+'" class="btn btn-danger btn-s remove_row"><i class="glyphicon glyphicon glyphicon-minus-sign"></i></button></td>';
          html_code += '</tr>';
          
          $('#invoice-item-table').append(html_code);

        });
        
        $(document).on('click', '.remove_row', function(){
          var row_id = $(this).attr("id");
          var total_item_amount = $('#order_item_final_amount'+row_id).val();
          var tax1_row_amount = $('#order_tax_rate_amount'+row_id).val();
          if(isNaN(parseFloat(tax1_row_amount )))
            tax1_row_amount = parseFloat(0.);
          var row_item_total_actual_amount = $('#order_item_amount'+row_id).val();
          var tax_rate = $('#tax_rate').text();

          var final_amount = $('#final_total_amt').text();
          var tax1_total_amount = $('#final_total_tax_amt').text();
          var total_row_pretax = $('#order_item_subtotal_pretax').text();

          var result_amount = parseFloat(final_amount) - parseFloat(total_item_amount);
          var result_tax1_amount = parseFloat(tax1_total_amount) - parseFloat(tax1_row_amount);
          var result_item_total_actual_amount = parseFloat(total_row_pretax) - parseFloat(row_item_total_actual_amount);
          var tax_average_amount = + parseFloat(tax_average_amount) + (parseFloat(tax1_row_amount)*parseFloat(0.5));

          /*
           * global total all rows
           */
          $('#final_total_amt').text(result_amount.toFixed(0));

          /*
           * total tax per row
           */
          $('#final_total_tax_amt').text(result_tax1_amount.toFixed(2));
          $('#order_total_tax_amount').val(result_tax1_amount.toFixed(2));

          /*
           *subtotal pre-tax amount per row
           */
          $('#order_item_subtotal_pretax').text(result_item_total_actual_amount.toFixed(2));
          $('#order_total_pretax').val(result_item_total_actual_amount.toFixed(2));

          /*
           * tax rate
           */
           $('#tax_rate').text(tax_average_amount.toFixed(0));


          $('#row_id_'+row_id).remove();
          count--;
          $('#total_item').val(count);
        });

        function cal_final_total(count)
        {
          var final_item_total = 0;
          var tax1_total_amount = 0;
          var item_total_actual_amount = 0;
          for(j=1; j<=count; j++)
          {
            var quantity = 0;
            var price = 0;
            var actual_amount = 0;
            var tax1_rate = 0;
            var tax1_amount = 0;
            var item_total = 0;
            var tax_average_amount = 0;
            quantity = $('#order_item_quantity'+j).val();
            if(quantity > 0)
            {
              price = $('#order_item_price'+j).val();

              if(price > 0)
              {
                actual_amount = parseFloat(quantity) * parseFloat(price);
                $('#order_item_amount'+j).val(actual_amount);
                tax1_rate = $('#order_tax_rate'+j).val();

                if(tax1_rate > 0)
                {
                  tax1_amount = parseFloat(actual_amount)*parseFloat(tax1_rate)/100;

                  $('#order_tax_rate_amount'+j).val(tax1_amount);
                }

                item_total = parseFloat(actual_amount) + parseFloat(tax1_amount);

                final_item_total = parseFloat(final_item_total) + parseFloat(item_total);
                item_total_actual_amount = parseFloat(item_total_actual_amount) + parseFloat(actual_amount);
                tax1_total_amount = parseFloat(tax1_total_amount) + parseFloat(tax1_amount);
                tax_average_amount = (parseFloat(tax1_total_amount)*parseFloat(.5)); 

                $('#order_item_final_amount'+j).val(item_total);
              }
            }
          }
          $('#final_total_amt').text(final_item_total.toFixed(2));

          $('#final_total_tax_amt').text(tax1_total_amount.toFixed(2));
          $('#order_total_tax_amount').val(tax1_total_amount.toFixed(2));


          $('#order_item_subtotal_pretax').text(item_total_actual_amount.toFixed(2));
          $('#order_total_pretax').val(item_total_actual_amount.toFixed(2));
          /*
           * tax rate
           */
           $('#tax_rate').text(tax_average_amount.toFixed(0)); 
        }

        $(document).on('blur', '.order_item_price', function(){
          cal_final_total(count);
        });

        $(document).on('blur', '.order_tax_rate', function(){
          cal_final_total(count);
        });

      });
      </script>      

<!-- division/nav -->

            </div>
        </div>
    </div>
</nav>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
