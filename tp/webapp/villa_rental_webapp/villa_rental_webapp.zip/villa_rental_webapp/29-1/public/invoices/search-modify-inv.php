<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

session_start();

require_once('../../private/initialize.php');
require_once('../../private/functions.php');

/*
if(!isset($_SESSION['access_token'])) {
  header("Location: " . PROJECT_ROOT ."/google-login.php");
  exit(); 
}
 */

  global $db;
  
  $name = "";
  $orderno = "";
  
  /* Search bar input string parser */ 
  $queryCondition = "";
  if(!empty($_POST["search"])) {
    foreach($_POST["search"] as $k=>$v){
      if(!empty($v)) {

        $queryCases = array("name","orderno");
        if(in_array($k,$queryCases)) {
          if(!empty($queryCondition)) {
            $queryCondition .= " AND ";
          } else {
            $queryCondition .= " WHERE ";
          }
        }
        switch($k) {
          case "name":
            $name = $v;
            $queryCondition .= "order_receiver_name LIKE '" . $v . "%'";
            break;
          case "orderno":
            $phone = $v;
            $queryCondition .= "order_no LIKE '" . $v . "%'";
            break;
        }
      }
    }
  }

  if (isset($_GET['pageno'])) {
        $pageno = $_GET['pageno'];
  } else {
        $pageno = 1;
  }

  $no_of_records_per_page = 10;
  $offset = ($pageno-1) * $no_of_records_per_page;

  $total_pages = find_total_pages_in_invoices($no_of_records_per_page);

  $subject_set = find_invoices_by_pages($no_of_records_per_page, $offset, $queryCondition);

?>

<?php $page_title = 'Customers'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>


<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

  <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
            <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
            <li><br></li>
            <li><table style="width: 107px;">
          <tbody>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
          </tr>          
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
          </tr>
          </tbody>
          </table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

              <div id="content">
                <div class="subjects listing">

                  <div id="frmTable">
                     <h1>Customer Invoices</h1>
                     <br>
                    <form name="frmSearch" method="post" action="<?php echo url_for('../public/invoices/search-modify-inv.php'); ?>">
                    <div class="search-box">
                    <p><input type="text" placeholder="Guest Name" name="search[name]" class="demoInputBox" value="<?php echo $name; ?>"  /><input type="text" placeholder="Invoice #" name="search[orderno]" class="demoInputBox" value="<?php echo $orderno; ?>" /><input type="submit" name="go" class="btnSearch" value="Search"><input type="reset" class="btnSearch" value="Reset" onclick="window.location='<?php echo url_for('../public/invoices/search-modify-inv.php'); ?>'"></p>
                    </div>


              <table class="table">
                <tr>
                  <th>Invoice ID</th>
                  <th>Bill Name</th>
                  <th>Bill Invoice Date</th>
                  <th>Invoice Due Date</th>
                  <th>Item Total</th>
                  <th>Invoice Total</th>
                  <th>Actions</th>
                </tr>

                <?php while($subject = mysqli_fetch_assoc($subject_set)) { ?>
                  <tr>
                    <td><?php echo h($subject['order_no']); ?></td>
                    <td><?php echo h($subject['order_receiver_name']); ?></td>
                    <td><?php echo h($subject['order_date']); ?></td>
                    <td><?php echo h($subject['order_due_date']); ?></td>
                    <td><?php echo h($subject['order_item_final_amount']); ?></td>
                    <td><?php echo h($subject['order_total']); ?></td>
                    <td>
            <button type="button" class="btn btn-primary" title="PDF" onclick="location.href='<?php echo url_for('/public/invoices/invoice-edit.php?invoice_id=' . h(u($subject['invoice_id'])).'&items='.h(u($subject['order_item_count']))); ?>'"><i class="glyphicon glyphicon-list-alt">
              </i></button>
            <button type="button" class="btn btn-warning" title="Edit" onclick="location.href='<?php echo url_for('/public/invoices/invoice-edit.php?invoice_id=' . h(u($subject['invoice_id'])).'&items='.h(u($subject['order_row_id_count']))); ?>'"><i class="glyphicon glyphicon-pencil">
              </i></button>
            <button type="button" class="btn btn-danger" title="Delete" onclick="location.href='<?php echo url_for('../public/reservations/delete.php?id=' . h(u($subject['reservation_id']))); ?>'"><i class="glyphicon glyphicon-trash">
              </i></button>

                    </td>
                  </tr>
                <?php } ?>
              </table>

              <ul class="pagination">
                  <li><a href="?pageno=1">First</a></li>
                  <li class="<?php 
                  if($pageno <= 1){
                   echo 'disabled';
                    }
                     ?>">
                      <a href="<?php 
                  
                      if($pageno <= 1){
                       echo '#';
                      }
                      else {
                         echo "?pageno=".($pageno - 1); } 
                      ?>">Prev</a>
                  
                  </li>
                  <li class="<?php 
                  if($pageno >= $total_pages){
                   echo 'disabled'; } 
                   ?>">
                      <a href="<?php
                       if($pageno >= $total_pages){
                        echo '#';
                        } else {
                         echo "?pageno=".($pageno + 1); } 
                         ?>">Next</a>
                  </li>
                  <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
              </ul>

              <?php
                mysqli_free_result($subject_set);
              ?>
            </div>

          </div>

            </div>
        </div>
    </div>
</nav>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
