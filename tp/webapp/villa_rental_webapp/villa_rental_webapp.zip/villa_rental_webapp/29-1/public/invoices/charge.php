<?php
/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */
	require_once('../../private/initialize.php');
	require_once('../../private/functions.php');
	require_once('vendor/autoload.php');

	\Stripe\Stripe::setApiKey('sk_test_lg0qE1liUhGoLfez85MQaQYS00kLiQ3t57');

	/*
	 * Sanitize POST Array
	 */
	$POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);

	$name = $POST['guest_name'];
	$order_total = $POST['order_total'];
	$email = $POST['email'];
	$token = $POST['stripeToken'];

	/*
	 * User Info
	 */
	$address = "911 SW 21ST Ave";
	$city = "Portland";
	$state = "OR";
	$zip = "97205";
	$user_info = array("Name" => $name, "Address" => $address." ".$city, "State" => $state, "Zip Code" => $zip);

	/*
	 * Create Customer Stripe
	 */
	$customer = \Stripe\Customer::create(array(
		"name" => $name,
		"email" => $email,
		"source" => $token,
		"phone" => "4695697081",
		"description" => "Rustica Beach House Short Term",
		'metadata' => $user_info
	));

	/*
	 * Charge Customer
	 */
	$charge = \Stripe\Charge::create(array(
		"amount" => trim($order_total) * 100,
		"currency" => "usd",
		"description" => "Rustica Beach House Short Term",
		"customer" => $customer->id,

	));

	/*
	 * Redirect to success page
	 */
	header("Location: " . PROJECT_ROOT ."/public/invoices/success.php?tid=".$charge->id."&product=".$charge->description);



