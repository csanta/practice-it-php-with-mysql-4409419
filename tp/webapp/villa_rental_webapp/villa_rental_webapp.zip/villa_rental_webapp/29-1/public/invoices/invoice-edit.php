<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');
require_once('../../private/functions.php');
require_once('../../private/google_calendar_api.php');

/*
if(!isset($_SESSION['access_token'])) {
  header("Location: " . PROJECT_ROOT ."/google-login.php");
  exit();
}*/

$errors = [];
$order_row_id_count = $_GET["items"];
(int) $invoice_id = (int) $_GET['invoice_id'];

/*
 * Edit/save the invoice code path
 */
if(is_post_request()) {
  //$errors[0] .= " POST[name]: ".$_POST['order_receiver_name'];
  // Handle form values sent by new.php
  $invoice = [];
  (int) $inv_id_cnt = $invoice_id;
  for($i=0; $i < $order_row_id_count; $i++) {
    //$errors[$i] = "inv_id_cnt: ".$inv_id_cnt;
    $invoice['invoice_id'] = $inv_id_cnt;
    $invoice['order_receiver_name'] = $_POST['order_receiver_name'] ?? '';
    $invoice['order_receiver_phone'] = $_POST['order_receiver_phone'] ?? '';
    $invoice['order_receiver_email'] = $_POST['order_receiver_email'] ?? '';
    $invoice['order_receiver_address'] = $_POST['order_receiver_address'] ?? '';
    /*
     * Now do the MySQL update...
     */
    $result = update_invoice($invoice);
    (int) $inv_id_cnt += 1;
  }

  //$errors[1] = "email: ".$invoice['order_receiver_address'];

}
    /* Grab the invoice ID so that we can show it in the current page */
    $invoice = array();

    $order_no = find_order_no_by_invoice_id($invoice_id);
    $invoice = find_all_orders($order_no, $order_row_id_count);

    if($order_row_id_count)
    { 
      $order_total_before_tax = 0;
      $order_total_tax1 = 0;
      $order_total_tax2 = 0;
      $order_total_tax3 = 0;
      $order_total_tax = 0;
      $order_total_after_tax = 0;

      $order_item_name[$order_row_id_count];
      $order_num_nights[$order_row_id_count];
      $order_item_price[$order_row_id_count];
      $order_item_actual_amount[$order_row_id_count];
      $order_tax_rate[$order_row_id_count];
      $order_tax_amount[$order_row_id_count];
      $order_item_sub_total_amount[$order_row_id_count];


      for ($i = 0; $i < $order_row_id_count; $i++) {
        $final_total_amount_str .= '<tr id="row_id_2"><td><span id="sr_no">'.($i+1).'</span></td><td>'.$invoice[$i]['order_item_name'].'</td><td>'.$invoice[$i]['order_item_quantity'].'</td><td>'.$invoice[$i]['order_item_price'].'</td><td>'.$invoice[$i]['order_item_amount'].'</td><td>'.$invoice[$i]['order_tax_rate'].'</td><td>'.$invoice[$i]['order_tax_rate_amount'].'</td><td>'.$invoice[$i]['order_item_final_amount'].'</td></tr>';
      }
    }

?>
<?php $page_title = 'Edit Invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<!--Begin Modal Window-->
<div class="modal fade left" id="myModalAuthForm">
<div class="modal-dialog-form2">
<div class="modal-content">
<div class="modal-body">

  <div id="frmInvoiceStripe">
    <p align="right">
     <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></button>
   </p>
  <div align="center"><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" alt="" width="76" height="76" align="center"/><br><br><p>Invoice from Rustica Beach House</p><br>Billed to <strong><?php echo h($invoice[0]['order_receiver_name']); ?></strong><br> Invoice #000<?php echo h($invoice[0]['order_no']); ?><hr></div>
   <h3><p align="center"><strong>$<?php echo h($invoice[0]['order_total']); ?></strong> due on <?php echo h($invoice[0]['order_due_date']); ?></p> </h3>
  <br>
  

<form action="./charge.php" method="post" id="payment-form">
  <div class="form-row">

    <input type="" name="guest_name" class="form-control mb-3 StripeElement StripeElement--empty" value="<?php echo h($invoice[0]['order_receiver_name']); ?>" placeholder="Name"><br>
    <input type="email" name="email" class="form-control mb-3 StripeElement StripeElement--empty" value="<?php echo h($invoice[0]['order_receiver_email']); ?>" placeholder="Email">
    <!--<label for="card-element">
      Credit or debit card
    </label>-->
    <br>
    <div id="card-element" class="form-control">
      <!-- A Stripe Element will be inserted here. -->
    </div>

    <!-- Used to display form errors. -->
    <div id="card-errors" role="alert"></div>
  </div>
<br>
  <input type="hidden" name="order_total" value="<?php echo h($invoice[0]['order_total']); ?>" />
  <button>Submit Payment</button>
</form>
<br>
<hr>
<p align="center">If you have any questions, call Rustica Beach House at<br> <strong>(939) 529-1552</strong> or email us at <br><strong>rustica.fairwaycourts@gmail.com.</strong></p>
<script src="https://js.stripe.com/v3/"></script>
<script src="./js/charge.js"></script>

  <!--<button type="submit" id="send_auth_email_button_modal" class="btn-submit btn btn-primary">Send Email</button>-->

</div>

</div>

</div>
</div>
</div>


<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

	<div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
				    <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
				    <li><br></li>
				    <li><table style="width: 107px;">
					<tbody>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
          </tr>           
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
					</tr>
					<tr>
					<td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
					<td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
					</tr>
					</tbody>
					</table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

<!-- division/nav -->


<div id="content">

<div class="row box" id="login-box">
                <?php echo display_errors($errors); ?>
  <div class="col-sm-14 col-sm-offset-14">
    <div class="panel panel-login">
      <div class="alert ">

<table style="width: 811px; height: 173px;">
<tbody>
<tr>
<td style="width: 180px;">
<p style="text-align: left;"><img class="center" src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" alt="Rustica" width="136" height="136" /></p>
</td>
<td style="width: 408.983px;">&nbsp;</td>
<td style="width: 199.017px; text-align: right;"><strong>INVOICE</strong><br><strong>Tortuga Properties</strong><br /> 150 Candelero Drive<br /> APT 826<br /> Humacao 00791<br /> Puerto Rico<br /> 939-529-1552</td>
</tr>
</tbody>
</table>
<hr />
<form method="post" id="invoice_form">
<table style="width: 813px;" border="0">
<tbody>
<tr>
<td style="width: 172.367px;">
<table>
<tbody>
<tr>
<td><strong></strong></td>
<td><input class="" style="width: 232px; padding: 4px 4px; text-align: left;" name="order_receiver_name" type="text" placeholder="Name" value="<?php echo h($invoice[0]['order_receiver_name']); ?>" />
<input class="" style="width: 232px; padding: 4px 4px; text-align: left;" name="order_receiver_phone" type="text" placeholder="Phone" value="<?php echo h($invoice[0]['order_receiver_phone']); ?>" /><input class="" style="width: 232px; padding: 4px 4px; text-align: left;" name="order_receiver_email" type="text" placeholder="Email" value="<?php echo h($invoice[0]['order_receiver_email']); ?>" /><textarea id="guest_list" style="width: 240px; resize: none; padding: 4px 4px;" cols="72" name="order_receiver_address" rows="2" placeholder="Address"><?php echo h($invoice[0]['order_receiver_address']); ?></textarea></td>

</tr>
</tbody>
</table>
</td>
<td style="width: 53.6333px;">&nbsp;</td>
<td style="width: 10px; text-align: right;">
<table style="height: 175px; width: 276px;" border="0" align="right">
<tbody>
<tr style="height: 18px;">
<td style="width: 117.85px; height: 18px; text-align: right; padding: 0px;"><strong>Invoice Num:</strong></td>
<td style="width: 129.15px; height: 18px; text-align: left; padding: 4px 8px;"><input class="demoInputBox" style="width: 100px; padding: 4px 4px; text-align: center;" disabled="disabled" name="last_name" type="text" value="<?php echo h($order_no); ?>" /></td>
</tr>
<td style="width: 117.85px; height: 18px; text-align: right; padding: 0px;"><strong>Invoice Date:</strong></td>
<td style="width: 129.15px; height: 18px; text-align: left; padding: 4px 8px;"><input style="width: 100px; padding: 4px 4px; text-align: center;" id="event-end-time" type="text" value="<?php echo h($invoice[0]['order_date']); ?>" /></td>
</tr>
<tr style="height: 18px;">
<td style="width: 117.85px; height: 18px; text-align: right; padding: 0px;"><strong>Payment Due:</strong></td>
<td style="width: 129.15px; height: 18px; text-align: left; padding: 4px 8px;"><input style="width: 100px; padding: 4px 4px; text-align: center;" id="event-end-time" type="text" value="<?php echo h($invoice[0]['order_due_date']); ?>" /></td>
</tr>
<tr style="height: 18px;">
<td style="width: 117.85px; height: 18px; text-align: right; padding: 0px;">&nbsp;</td>
<td style="width: 129.15px; height: 18px; text-align: left; padding: 4px 8px;">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

<br>

        <div class="table-responsive">
         <!-- <table class="table" border="1">-->

            <tr>
                <td colspan="2">
    
                  <br />
                  <table id="invoice-item-table" class="table table-striped table-hover table-" style="margin-bottom:0px">
                    <tr>
                      <th style="width: 4%; text-align: center; background-color: #e84353; color: white;">#</th>
                      <th style="width: 19%; text-align: center; background-color: #e84353; color: white;">Items</th>
                      <th style="width: 8%; text-align: center; background-color: #e84353; color: white;">Quantity</th>
                      <th style="width: 5%; text-align: center; background-color: #e84353; color: white;">Price</th>
                      <th style="width: 11%; text-align: center; background-color: #e84353; color: white;">Amount</th>
                      <th style="width: 11.5%; text-align: center; background-color: #e84353; color: white;" colspan="2">Room Tax (%)</th>
                      <th style="width: 6.5%; text-align: center; background-color: #e84353; color: white;" rowspan="1">Total</th>
                    </tr>
                    <tr>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th>Rate</th>
                      <th>Amt.</th>
                      <th></th>
                    </tr>
            <script type="text/javascript">
                var table_row = '';
                table_row = '"<?php echo $final_total_amount_str; ?>"';
                $('#invoice-item-table').append(table_row);
            </script>                    
                  </table>

                </td>
              </tr>


          <!--</table>-->
<table style="width: 360px;" align="right" border="0" class="table table-hover table-">
<tbody>
<tr>
<td style="width: 195.0px; text-align: right;"><div align="left"><strong>Subtotal:</strong></div></td>
<td style="width: 1.35px; text-align: right;"><strong>$<?php echo h($invoice[0]['order_total_pretax']); ?></strong></td>
</tr>
<tr>
<td style="width: 195.0px; text-align: right;"><div align="left"><strong>Room Tax(<?php echo h($invoice[0]['order_tax_rate']); ?>%):</strong></div></td>
<td style="width: 1.35px; text-align: right;"><strong>$<?php echo h($invoice[0]['order_total_tax_amount']); ?></strong></td>
</tr>
<tr>
<td style="width: 195.0px; text-align: right; background-color: #E8E8E8;"><div align="left"><strong>Total Due:</strong></div></td>
<td style="width: 1.35px; text-align: right; background-color: #E8E8E8;"><strong>$<?php echo h($invoice[0]['order_total']); ?></td>
</tr>

<tr>
<td style="width: 1.65px;" colspan="1" align="left"><input id="total_item" name="total_item" type="hidden" value="1" /></td>
<td style="width: 195.0px; text-align: right;"></td>
</tr>
</tbody>
</table>           
        </div>
                  <input type="hidden" name="total_item" id="total_item" value="1" />
                  <table style="margin-left: auto; margin-right: auto;">
                  <tbody>
                  <tr>
                  <td><button type="submit" name="commit" class="btn-submit btn btn-info center">Save Invoice</button></td>
                  <td><button class="btn-submit btn btn-info center" type="button" type="button" data-toggle="modal" data-target="#myModalAuthForm">Pay Invoice</button></td>
                  </tr>
                  </tbody>
                  </table>
      </form>

<!-- division/nav -->

            </div>
        </div>
    </div>

</nav>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>
