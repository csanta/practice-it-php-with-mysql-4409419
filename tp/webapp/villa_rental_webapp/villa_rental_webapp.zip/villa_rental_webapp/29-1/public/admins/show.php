<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

require_once('../../private/initialize.php');

if(!isset($_SESSION['access_token'])) {
  redirect_to(url_for('../google-login.php'));
  exit(); 
}

$id = $_GET['id'] ?? '1'; // PHP > 7.0
$admin = find_admin_by_id($id);

?>

<?php $page_title = 'Show Admin'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

    <a class="back-link" href="<?php echo url_for('../public/admins/index.php'); ?>">&laquo; Back to Admin</a>
    <p>
    <p>
  <div class="admin show">

    <h1>Admin: <?php echo h($admin['username']); ?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('../public/admins/edit.php?id=' . h(u($admin['id']))); ?>">Edit</a>
      <a class="action" href="<?php echo url_for('../public/admins/delete.php?id=' . h(u($admin['id']))); ?>">Delete</a>
    </div>

    <div class="attributes">
      <dl>
        <dt>First name</dt>
        <dd><?php echo h($admin['first_name']); ?></dd>
      </dl>
      <dl>
        <dt>Last name</dt>
        <dd><?php echo h($admin['last_name']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($admin['email']); ?></dd>
      </dl>
      <dl>
        <dt>Username</dt>
        <dd><?php echo h($admin['username']); ?></dd>
      </dl>
    </div>

  </div>

</div>

