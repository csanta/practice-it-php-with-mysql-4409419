<?php

/*
 * Copyright (c) 2019 - Carlos Santa - santa.cm@gmail.com
 *
 * Licensed under The MIT License: https://opensource.org/licenses/mit-license.php
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 */

session_start();

require_once('./private/initialize.php');
require_once('./private/functions.php');

/*
if(!isset($_SESSION['access_token'])) {
	redirect_to(url_for('../google-login.php'));
  header("Location: " . PROJECT_ROOT ."/google-login.php");
	exit();	
}
 */

//poking at the DB 
//$id = '1'; // PHP > 7.0
//$reservation = find_subject_by_id($id);
//echo " reservation [ name ] : " . $reservation['last_name'];


$villas = array(
  array(
    "name" => "Rustica",
    "id" => 830
  ),
  array(
    "name" => "Tortuga",
    "id" => 826
  ),
  array(
    "name" => "Acqualina",
    "id" => 778
  ),
  array(
    "name" => "Solana",
    "id" => 752
  ),  
);

$platforms = array(
  array(
    "name" => "Booking.com",
  ),
  array(
    "name" => "AirBnB.com",
  ),
  array(
    "name" => "VRBO.com",
  ),
  array(
    "name" => "Direct Carlos",
  ),
  array(
    "name" => "Direct Serge",
  ),   
);

?>

<?php include(SHARED_PATH . '/staff_header.php'); ?>

<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">

  <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <ul class="nav nav-sidebar">
            <li><img src="<?php echo PROJECT_ROOT?>/public/images/rustica_logo.png" width="76" height="76" alt="Rustica" class="center"/></li>
            <li><br></li>
            <li><table style="width: 107px;">
          <tbody>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Invoices" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/invoice.php?id=1">New Invoice</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/invoices/search-modify-inv.php">Search and Modify Invoices</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/new_file2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/home.php">New Reservation</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/search_glass.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/reservations/search-modify-res.php">Search and Modify Reservations</a></td>
          </tr>
          <tr>
          <td style="width: 6.8833px;"><img class="left" src="<?php echo PROJECT_ROOT?>/public/images/admin2.png" alt="Reservations" width="32" height="32" /></td>
          <td style="width: 4.117px;"><a id="logo" href="<?php echo PROJECT_ROOT?>/public/admins/index.php">Admins</a></td>
          </tr>
          </tbody>
          </table></li>

                </ul>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

              <div id="content">

               <p>
               <p>

              <div id="frmToy">
                <h1>Create A New Reservation</h1>
                <br>
                <dl>
                  <dt>Check in:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-start-time" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Check-out:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-end-time" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>First Name:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-first-name" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Last Name:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-last-name" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Email:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-email" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Street:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-street" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>City:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-city" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>State:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-state" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Zip:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-zip" autocomplete="off" value="00000"/>
                  </dd>
                </dl>
                <dl>
                  <dt>Phone:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-phone" autocomplete="off" />
                  </dd>
                </dl>
                <dl>
                  <dt>Booking Platform:</dt>
                  <dd>
                    <select style="width: 550px;" id="event-booking-platform"  autocomplete="off">
                            <?php
                              foreach ($platforms as $key => $val) {
                                echo "<option value=\"{$platforms[$key]["name"]}\"";
                                //if($villas[i]["id"] == $i) {
                                  //echo " selected";
                                //}
                                echo ">{$platforms[$key]["name"]}</option>";
                              }
                            ?>
                    </select>
                  </dd>
                </dl>
                <dl>
                  <dt>Total # of Guests:</dt>
                  <dd>
                    <input style="width: 550px;" type="text" id="event-total-guests" autocomplete="off" value="1"/>
                  </dd>
                </dl>
                <dl>
                  <dt>Name of Guests:</dt>
                  <dd>
                    <textarea style="width: 550px; resize:none" rows="3" cols="72" name="guest_list" id="guest_list"> Enter Guest list here...</textarea>
                  </dd>
                </dl>
                <dl>
                  <br>
                  <dt>Villa Name:</dt>
                  <dd>
                    <select style="width: 550px;" id="event-villa-name"  autocomplete="off">
                            <?php
                              foreach ($villas as $key => $val) {
                                echo "<option value=\"{$villas[$key]["name"]}\"";
                                //if($villas[i]["id"] == $i) {
                                  //echo " selected";
                                //}
                                echo ">{$villas[$key]["name"]}</option>";
                              }
                            ?>
                    </select>
                  </dd>
              </dl>
              <dl>
                <dt>Villa ID:</dt>
                <dd>
                  <select style="width: 550px;" id="event-villa-id"  autocomplete="off">
                          <?php
                            foreach ($villas as $key => $val) {
                              echo "<option value=\"{$villas[$key]["id"]}\"";
                              //if($villas[i]["id"] == $i) {
                                //echo " selected";
                              //}
                              echo ">{$villas[$key]["id"]}</option>";
                            }
                          ?>
                  </select>
                </dd>
              </dl>
                <!--<button id="create-update-event" data-operation="create" data-event-id="">Create Event</button>-->
                  <button id="create-update-event" data-operation="create" data-event-id="" >Create Reservation</button>
                <button id="delete-event" style="display:none">Delete Event</button>
              </div>

              <br>

                <div class="subject new">

                  <?php echo display_errors($errors); ?>

                </div>

              </div>



            </div>
        </div>
    </div>
</nav>



<script>

// Selected time should not be less than current time
function AdjustMinTime(ct) {
	var dtob = new Date(),
  		current_date = dtob.getDate(),
  		current_month = dtob.getMonth() + 1,
  		current_year = dtob.getFullYear();
  			
	var full_date = current_year + '-' +
					( current_month < 10 ? '0' + current_month : current_month ) + '-' + 
		  			( current_date < 10 ? '0' + current_date : current_date );

	if(ct.dateFormat('Y-m-d') == full_date)
		this.setOptions({ minTime: 0 });
	else 
		this.setOptions({ minTime: false });
}

// DateTimePicker plugin : http://xdsoft.net/jqplugins/datetimepicker/
$("#event-start-time, #event-end-time").datetimepicker({ format: 'Y-m-d H:i', minDate: 0, minTime: 0, step: 5, onShow: AdjustMinTime, onSelectDate: AdjustMinTime });
$("#event-date").datetimepicker({ format: 'Y-m-d', timepicker: false, minDate: 0 });

$("#event-type").on('change', function(e) {
	if($(this).val() == 'ALL-DAY') {
		$("#event-date").show();
		$("#event-start-time, #event-end-time").hide();
	}
	else {
		$("#event-date").hide(); 
		$("#event-start-time, #event-end-time").show();
	}
});

// Send an ajax request to create event
$("#create-update-event").on('click', function(e) {
	var blank_reg_exp = /^([\s]{0,}[^\s]{1,}[\s]{0,}){1,}$/,
		error = 0,
		parameters;

	$(".input-error").removeClass('input-error');

	if(!blank_reg_exp.test($("#event-title").val())) {
		$("#event-title").addClass('input-error');
		error = 1;
	}

	if($("#event-type").val() == 'FIXED-TIME') {
		if(!blank_reg_exp.test($("#event-start-time").val())) {
			$("#event-start-time").addClass('input-error');
			error = 1;
		}		

		if(!blank_reg_exp.test($("#event-end-time").val())) {
			$("#event-end-time").addClass('input-error');
			error = 1;
		}
	}
	/*else if($("#event-type").val() == 'ALL-DAY') {
		if(!blank_reg_exp.test($("#event-date").val())) {
			$("#event-date").addClass('input-error');
			error = 1;
		}	
	}*/

	if(error == 1)
		return false;

	if($("#event-type").val() == 'FIXED-TIME') {
		// If end time is earlier than start time, then interchange them
		if($("#event-end-time").datetimepicker('getValue') < $("#event-start-time").datetimepicker('getValue')) {
			var temp = $("#event-end-time").val();
			$("#event-end-time").val($("#event-start-time").val());
			$("#event-start-time").val(temp);
		}
	}


  $reservation = [];

    var house_id = $("#event-villa-id").val();
	var event_house_name = $("#event-villa-name").val();
    var event_house_name_plus_id = "";
    var event_house_name_plus_id2 = "";

    if(event_house_name == "Solana")
    	event_house_name_plus_id2 = event_house_name_plus_id.concat(house_id,"-", event_house_name, "-");
    else if(event_house_name == "Acqualina")
    	event_house_name_plus_id2 = event_house_name_plus_id.concat(house_id,"-", event_house_name, "-");
    else if(event_house_name == "Tortuga")
    	event_house_name_plus_id2 = event_house_name_plus_id.concat(house_id,"-", event_house_name, "-");
    else 
    	event_house_name_plus_id2 = "830-Rustica"/*event_house_name_plus_id.concat("830-", event_house_name, "-")*/;

	//first name + ''
	var guest_name = $("#event-first-name").val();
	guest_name = guest_name.concat(" ");

	//var guest_last = $("#event-last-name").val();

	//first + last name
	var fullname = guest_name.concat($("#event-last-name").val());

	var email = $("#event-email").val();
	var phone = $("#event-phone").val();

	var title_house_id_plus_first_last = event_house_name_plus_id2.concat(" - ", fullname);

    /* Booking platform */
    var event_booking_platform = $("#event-booking-platform").val();

	var rest ="";
	var rest2 = rest.concat(rest, " - #7 adults - ", event_booking_platform);
	var title3 = title_house_id_plus_first_last.concat(rest2);

	var location2 = "";
	var location3 = location2.concat(location2, event_house_name, " ", " - Tortuga Properties Vacation Rental At Fairway Courts, Palmas Del Mar, 150 Candelero Dr, Humacao, 00791, Puerto Rico");

    /* Event date and time */
    var user_start_time = $("#event-start-time").val();
    var user_end_time = $("#event-end-time").val();
    /* Scratch temp vars so that the GAPI Event description's time only shows date without timestamp */
    var temp_user_start_time = user_start_time.substring(0, 10);
    var temp_user_end_time = user_end_time.substring(0, 10);

    /* GAPI Event description string */
	var event_description = "";
    var event_description2 = event_description.concat("Name: ",fullname,"\nCheckin: ",temp_user_start_time, "\n", "Checkout: ", temp_user_end_time, "\n", "Email: ",email, "\n", "Phone: ",phone, "\n");

    /* Event color id */
    var event_color_id = "";
    if(event_house_name == "Solana")
    	event_color_id = 5; /*Orange*/
    else if(event_house_name == "Acqualina")
    	event_color_id = 3; /*Purple */
    else if(event_house_name == "Tortuga")
    	event_color_id = 11; /*Red*/
    else 
    	event_color_id = 9; /*Blue*/

	// Event details
	parameters = { 	title: title3,
					description: event_description2,
					location: location3,
					colorId: event_color_id,
					event_time: {
						start_time: user_start_time.replace(' ', 'T') + ':00',
						end_time: user_end_time.replace(' ', 'T') + ':00',
						event_date: null
					},
					all_day: 0,
					operation: $(this).attr('data-operation'),
					event_id: $(this).attr('data-operation') == 'create' ? null : $(this).attr('data-event-id'),
					first_name: guest_name,
					last_name: $("#event-last-name").val(),
					email: email,
					phone: phone,
					street: $("#event-street").val(),
					city: $("#event-city").val(),
					state: $("#event-state").val(),
					zip: $("#event-zip").val(),
					platform: event_booking_platform,
					total_guests: $("#event-total-guests").val(),
					villa_name: event_house_name,
					villa_id: house_id,
					check_in: user_start_time,
					check_out: user_end_time,
					gapi_calendar_id: "",
					guest_list: $("#guest_list").val()
				};

	$("#create-update-event").attr('disabled', 'disabled');
	$.ajax({
        type: 'POST',
        url: 'ajax.php',
        data: { event_details: parameters },
        dataType: 'json',
        success: function(response) {
        	$("#create-update-event").removeAttr('disabled');
          //console.log('Before: Event created with ID : ' + response.event_id);

        	if(parameters.operation == 'create') {
             /* Redirect to editing the just created reservation */
            /*console.log('Event created with ID : ' + response.event_id);
            console.log('Servers response: ' + response.status);
        		console.log('Server: First Name: ' + response.first_name);
        		console.log('Server: Last Name: ' + response.last_name);
        		console.log('Server: Email: ' + response.email);
        		console.log('Server: Phone: ' + response.phone);
        		console.log('Server: Street: ' + response.street);
        		console.log('Server: City: ' + response.city);
        		console.log('Server: State: ' + response.state);
        		console.log('Server: Zip: ' + response.zip);
        		console.log('Server: Platform: ' + response.platform);
        		console.log('Server: Check-in: ' + response.check_in);
        		console.log('Server: Check-out: ' + response.check_out);
        		console.log('Server: Total Guests: ' + response.total_guests);
        		console.log('Server: Villa ID: ' + response.villa_id);
        		console.log('Server: Villa Name: ' + response.villa_name);
        		console.log('Server: GAPI Calendar ID: ' + response.gapi_calendar_id);
				    console.log('Server: Guest List: ' + response.guest_list);
        		console.log('parameters.title : ' + parameters.title);
        		console.log('parameters.description : ' + parameters.description);
        		console.log('parameters.location : ' + parameters.location);
        		console.log('parameters.color : ' + parameters.colorId);
        		console.log('parameters.event_time.start_time : ' + parameters.event_time.start_time);
        		console.log('parameters.event_time.end_time : ' + parameters.event_time.end_time);
        		console.log('parameters.event_time.event_date : ' + parameters.event_time.event_date);
        		console.log('parameters.event_time.all_day : ' + parameters.all_day);
        		console.log('parameters.event_time.operation : ' + parameters.operation);
            console.log('parameters.event_time.event_id : ' + parameters.event_id);*/
            window.location.assign('http://www.rusticasoftware.com/villa_rental_webapp/29-1/public/reservations/edit.php?id=' + response.status);
        	}
        	else if(parameters.operation == 'update') {
        		alert('Event ID ' + parameters.event_id + ' updated');
        	}
        },
        error: function(response) {
            $("#create-update-event").removeAttr('disabled');
            alert(response.responseJSON.message);
        }
    });
});

</script>

</body>
</html>
