# villa_rental_webapp

This is a property management system web application for short term vacation rental properties. It manages the reservation database using MySQL. It uses also the Google Calendar APIs to export the reservations into a shareable Google Calendar. Lastly it tries to automate common tasks such as sending emails with attachments.